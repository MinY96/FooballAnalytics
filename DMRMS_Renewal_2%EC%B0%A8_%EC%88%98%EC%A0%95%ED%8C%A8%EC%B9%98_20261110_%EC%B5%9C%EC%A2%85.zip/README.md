# DM RMS Renewal — 2차 수정 패치 (2026-11-10)

본 패치는 사용자가 수정 후 GitHub에 올린 **`MinY96/DMRMS_Renewal`의 최신 `master` 코드**를 기준으로 작성했습니다. 기존 1차 패치가 먼저 반영된 저장소에서만 실행하세요. 패치 실행 자체가 GitHub에 커밋되지는 않으며, 서버/DB에 자동으로 배포되지 않습니다.

## 1. 변경 내용

| 구분 | 요청 | 적용 사항 |
|---|---|---|
| Recipe 관리 | Matching Rate가 `0.99%`로 보임 | WPF `N2%` → `P2` 포맷 (0.99 → 99.00%) |
| Master 관리 | Master 미등록 모델의 기준정보가 비어 있음 | `dm_recipe_info` + `dm_master_recipe_info`에서 Model별 기준정보 조회 |
| Master 관리 | Master 미등록 모델의 Parameter/고유값이 비어 있음 | `dm_recipe_para` + `dm_recipe_info`에서 파싱된 Parameter 및 고유값 조회. 기존 Master 값도 함께 반영 |
| Master 관리 | 템플릿의 문자열 ComboBox가 비어 있음 | Parameter 선택지에서 `allowed_values` 보완 |
| No Master 조회 | Model 선택 기능 없음 | 상단 Model 콤보박스 추가, Model 변경 시 자동 재조회 |
| 기타 | 불일치/집계 제외 탭 진입 시 최신 내용 미조회 | 선택 탭이 바뀌면 API 재조회; 시작 시 불필요한 전체 상세 테이블 조회 제거 |
| 예외 처리 | FAB2 No Master 0건 조회 시 반환 형태 불일치, NULL 그룹 포맷 가능성 | FAB1/2 반환 형식 통일, NULL 그룹 번호 안정화 |
| 문서 | README 및 운영 명령어 정리 | 한글 문서 및 실제 서버 실행 명령 포함 |

**변경하지 않은 영역:** `1_backup` 수집·파싱·집계, DB 스키마/테이블, 사용자 인증, 기존 Recipe 삭제·백업 로직, Master 생성·수정·삭제 프로세스의 업무 규칙. UI/UX 대규모 개편도 적용하지 않았습니다.

## 2. 적용 절차 (Windows PowerShell)

먼저 저장소의 수정 내용을 Git에 커밋하거나 별도로 백업한 뒤, 이 ZIP 압축을 해제합니다. `apply_patch.py`는 **프로젝트 밖**에서 실행해도 됩니다.

```powershell
# 1. 수정 예정 코드의 호환성 검증만 수행 (파일 변경 없음)
py -3.12 .\apply_patch.py --root 'D:\DMRMS_Renewal' --dry-run

# 2. 전체 호환성 검증 성공 후 실제 소스 수정
py -3.12 .\apply_patch.py --root 'D:\DMRMS_Renewal'

# 3. 변경된 파일 확인
cd D:\DMRMS_Renewal
git status --short
git diff --stat
git diff

# 4. WPF 빌드 (Windows .NET SDK 필요)
dotnet build 3_frontend\DM_RMS.Wpf.sln -c Release
```

- 스크립트는 기존 소스의 **고유한 수정 위치**를 사전 검증합니다. 현재 GitHub와 코드를 더 수정한 경우 호환성 검증이 실패할 수 있습니다.
- 수정 대상 기존 파일은 `.dmrms_patch_backup_v2_YYYYMMDD_HHMMSS/`에 복사합니다. 이 폴더는 Git에 올리지 마세요.
- 프로젝트 루트의 `README.md`, 사업장별 `2_server/fab*/README.md`, `docs/서버_운영_명령어.md`도 함께 한글로 정리합니다.
- 운영 PC로 코드 적용 시 `1_backup`과 `2_server`가 독립 프로세스/별도 PC에서 동작하는 점을 고려해 **FAB별로 배포 및 재기동**해야 합니다.

## 3. 중요한 동작 설명

### 3.1 Matching Rate

API가 주는 값이 `0.99`인 경우 WPF의 `P2` 포맷을 이용하여 `99.00%`로 표시합니다. DB의 값을 **이미 99.0으로 저장하는 데이터**에는 적용하지 않아야 합니다. 이번 변경은 현재 `0.99%`로 잘못 나타나는 원본 데이터 구조(0~1 비율)를 전제로 합니다.

### 3.2 기준정보·Parameter 선택지

기존 Master 정보만 참조하면 `KLA2139` 같은 Master 등록 모델만 보입니다. 신규 Model을 등록할 수 있도록 실제 파싱 완료된 Recipe 기준으로 고유값을 조회하며, 기존에 저장된 Master 선택지도 유지합니다. 문자열 Parameter 고유값은 **모델 전체를 한 번에 조회**하여 Parameter별 다수의 DB 요청(N+1)을 줄였습니다.

**신규 Model에 기존 Master가 전혀 없는 경우 기본 Master 템플릿 행은 비어 있는 것이 정상입니다.** 우측 Parameter 선택 콤보박스에서 파싱된 항목을 추가하고, 기준값은 사용자가 검토하여 지정합니다. 자동으로 장비 Recipe를 Master로 승인하는 동작은 위험하므로 추가하지 않았습니다.

### 3.3 Model 선택에 따른 No Master 조회

`/api/no_master_detail/models`에서 목록을 조회합니다. Model 선택 후 `/api/no_master_detail/data?model=...`를 호출하며, 다른 Model로 빠르게 변경해도 이전 API 응답이 새 결과를 덮어쓰지 않도록 요청 버전을 확인합니다. Model을 선택하지 않으면 불필요한 상세 조회를 하지 않습니다.

### 3.4 불일치/집계 제외 조회

프로그램 시작 시 모든 상세 테이블을 일괄 조회하던 흐름을 바꿨습니다. 해당 탭으로 이동하면 최신 서버 데이터를 조회하고, **새로고침** 버튼도 계속 사용할 수 있습니다. No Master 탭은 Model 선택 전에는 상세 테이블을 조회하지 않습니다.

## 4. 서버 운영 명령어

상세 명령어와 설정 설명은 **[`docs/서버_운영_명령어.md`](docs/서버_운영_명령어.md)**를 확인하세요. API 개발 실행, Waitress 운영 실행, FAB별 백업 실행, `/api/health` 점검, Model별 API 테스트 예시를 모두 포함했습니다.

실제 서버 구조에 맞춘 핵심 명령만 요약하면 아래와 같습니다.

```powershell
# FAB1 API 서버 개발 실행
cd D:\DMRMS_Renewal\2_server\fab1
.\.venv\Scripts\python.exe run.py

# FAB1 API 서버 운영 실행(Waitress)
.\.venv\Scripts\waitress-serve.exe --listen=0.0.0.0:5051 --call src:create_app

# FAB2는 2_server\fab2 폴더에서 동일하게 실행(포트/환경설정 확인)

# FAB1 수집·파싱·집계 배치 수동 실행
cd D:\DMRMS_Renewal\1_backup\fab1
.\.venv\Scripts\python.exe run.py
```

**중요:** 현재 `1_backup/fab2/run.py`의 `collector.run()` 및 `parser.run()`이 주석 처리되어 있습니다. 별도의 수집·파싱 작업이 존재하는지 확인해야 합니다. 이번 2차 패치에서는 수집 프로그램을 변경하지 않았습니다.

## 5. 권장 검증 순서

1. FAB1/FAB2에서 `/api/health`, `/api/master/models` 호출에 성공하는지 확인합니다.
2. 기존 Master가 없는 Model(KLA2365, PUMA 등)을 선택하고 신규 Master 생성 팝업의 **기준정보/Parameter 목록**이 나타나는지 확인합니다. 실제 데이터가 해당 모델에 있어야 목록이 생성됩니다.
3. STRING Parameter의 `allowed_values`가 선택한 Model의 파싱 Recipe에서 조회되는지 확인합니다.
4. No Master 탭에서 서로 다른 Model로 이동할 때 결과가 정확히 교체되는지, No Master 0건인 Model에서도 예외 없이 빈 화면이 표시되는지 확인합니다.
5. 불일치 Recipe / 집계 제외 Recipe 탭을 다시 방문할 때 최신 데이터로 갱신되는지 확인합니다.
6. Recipe 관리 장비 현황의 Matching Rate가 `99.xx%`로 표시되는지 확인합니다.
7. WPF 프로그램의 `Release` 빌드, FAB1/FAB2 실서버 API 응답 및 사용자 권한별 기존 기능을 점검합니다.

## 6. 실행 환경·검증 범위

- 현재 GitHub 소스 기준으로 코드 흐름을 확인하고, Python 패치 스크립트에 **사전 검증**을 추가했습니다.
- 실제 PostgreSQL 테이블/데이터, FTP 장비, Windows WPF 빌드 환경에는 접근할 수 없어 실서버 통합 테스트는 수행하지 않았습니다.
- **DB 덤프는 대용량 PostgreSQL Custom Format 바이너리**로 GitHub 연결 기능에서 내부 스키마/데이터를 직접 분석하지 못했습니다. 컬럼 이름과 관계는 업데이트된 현재 서버 SQL을 근거로 사용했습니다.
- GitHub 공개 저장소에 DB 덤프 및 이전 패치 백업 폴더가 포함된 점을 확인했습니다. 기밀 데이터가 포함된 경우 즉시 공개 범위와 Git 이력을 확인하세요.
- 운영 계정·비밀번호·접속 URL은 외부에 게시하지 마세요.
