#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""DM RMS 리뉴얼 2차 소스 수정 패치.

2026-11-10 GitHub master 기준. 원본 코드의 고유 앵커를 먼저 검증하고,
모든 변경을 미리 계산한 뒤 별도 백업 디렉터리에 원본을 보관합니다.
운영 DB나 실제 설비에는 직접 접근하지 않습니다.
"""
from __future__ import annotations

import argparse
from datetime import datetime
from pathlib import Path
import shutil
import sys

FRONT = Path("3_frontend/DM_RMS.Wpf")
SERVER = Path("2_server")


def one(s: str, old: str, new: str, label: str) -> str:
    count = s.count(old)
    if count != 1:
        raise ValueError(f"[{label}] 변경 위치가 정확히 1개여야 합니다 (발견: {count}). 첫 부분: {old[:80]!r}")
    return s.replace(old, new, 1)


def section(s: str, start: str, end: str, replacement: str, label: str) -> str:
    if s.count(start) != 1 or s.count(end) != 1:
        raise ValueError(f"[{label}] 시작/종료 마커를 유일하게 찾지 못했습니다")
    head, remainder = s.split(start, 1)
    _, tail = remainder.split(end, 1)
    return head + replacement + end + tail


def frontend_format(s: str) -> str:
    return one(s, '"matching_rate" => "{0:N2}%",',
               '"matching_rate" => "{0:P2}",', 'Matching Rate를 100배 표시하는 표준 백분율 형식')


def frontend_api(s: str) -> str:
    return one(s,
        '''    public Task<ApiResponse<CusomDetailTableResponse>> GetNoMasterDetailAsync()
        => _api.GetAsync<CusomDetailTableResponse>("/api/no_master_detail/data");''',
        '''    public Task<ApiResponse<List<string>>> GetNoMasterModelOptionsAsync()
        => _api.GetAsync<List<string>>("/api/no_master_detail/models");

    public Task<ApiResponse<CusomDetailTableResponse>> GetNoMasterDetailAsync(string model)
        => _api.GetAsync<CusomDetailTableResponse>(
            $"/api/no_master_detail/data?model={Uri.EscapeDataString(model)}");''',
        'No Master 선택 모델의 API 전달')


def frontend_detail_vm(s: str) -> str:
    s = one(s, '    private readonly IDialogService _dialog;\n', '''    private readonly IDialogService _dialog;
    private readonly string _searchData;
    private string _selectedModel = string.Empty;
    private long _requestVersion;
    private bool _modelsLoaded;
''', 'Detail ViewModel 상태')
    s = one(s, '''        _api = api;
        _dialog = dialog;
        RefreshCommand = new AsyncRelayCommand(_ => LoadAsync(searchData));''',
        '''        _api = api;
        _dialog = dialog;
        _searchData = searchData;
        RefreshCommand = new AsyncRelayCommand(_ => ActivateAsync());''', 'Detail ViewModel 명령')
    s = one(s, '        _ = LoadAsync(searchData);\n',
        '        // 사용자가 해당 탭을 열 때에만 조회하여 불필요한 초기 API 요청을 방지합니다.\n',
        'Detail ViewModel 불필요한 초기 요청 제거')
    s = one(s, '''    public ObservableCollection<RecipeColumnFilter> ColumnFilters { get; } = new();''',
        '''    public ObservableCollection<RecipeColumnFilter> ColumnFilters { get; } = new();
    public ObservableCollection<string> Models { get; } = new();

    /// <summary>No Master 탭에서만 사용하는 Model입니다.</summary>
    public string SelectedModel
    {
        get => _selectedModel;
        set
        {
            if (!SetProperty(ref _selectedModel, value ?? string.Empty)) return;
            // 이전 Model 조회가 늦게 응답해도 현재 테이블을 덮어쓰지 않도록 무효화합니다.
            System.Threading.Interlocked.Increment(ref _requestVersion);
            DetailView = null;
            RowCount = 0;
            IsLoading = false;
            ColumnMetadata = new Dictionary<string, ColumnVisualizationInfo>(StringComparer.OrdinalIgnoreCase);
            ClearColumnFilters();
            if (_searchData == "no_master" && !string.IsNullOrWhiteSpace(_selectedModel))
                _ = LoadAsync();
        }
    }

    /// <summary>탭을 선택할 때 최신 내용을 다시 조회합니다.</summary>
    public async Task ActivateAsync()
    {
        if (_searchData == "no_master")
        {
            if (!_modelsLoaded)
                await LoadModelsAsync();
            if (string.IsNullOrWhiteSpace(SelectedModel)) return;
        }
        await LoadAsync();
    }

    private async Task LoadModelsAsync()
    {
        try
        {
            var response = await _api.GetNoMasterModelOptionsAsync();
            var options = (response.Data ?? new List<string>())
                .Where(model => !string.IsNullOrWhiteSpace(model))
                .Distinct(StringComparer.OrdinalIgnoreCase)
                .OrderBy(model => model, StringComparer.OrdinalIgnoreCase)
                .ToArray();
            Models.Clear();
            foreach (var model in options) Models.Add(model);
            _modelsLoaded = true;
            if (!options.Contains(SelectedModel, StringComparer.OrdinalIgnoreCase))
                SelectedModel = string.Empty;
        }
        catch (Exception ex)
        {
            _dialog.ShowError($"No Master Model 목록 조회 실패: {ex.Message}");
        }
    }

    private void ClearColumnFilters()
    {
        foreach (var filter in ColumnFilters)
            filter.PropertyChanged -= OnFilterChanged;
        ColumnFilters.Clear();
    }''', 'Detail Model 선택 및 탭 활성화')
    s = one(s, '''    public async Task LoadAsync(string searchData)
    {
        try
        {
            IsLoading = true;
            ApiResponse<CusomDetailTableResponse> response = null;
            switch (searchData)''',
        '''    public async Task LoadAsync(string? searchData = null)
    {
        var kind = searchData ?? _searchData;
        if (kind == "no_master" && string.IsNullOrWhiteSpace(SelectedModel))
            return;

        var requestVersion = System.Threading.Interlocked.Increment(ref _requestVersion);
        try
        {
            IsLoading = true;
            ApiResponse<CusomDetailTableResponse>? response = null;
            switch (kind)''', 'Detail 모델별 비동기 조회')
    s = one(s, 'response = await _api.GetNoMasterDetailAsync();',
            'response = await _api.GetNoMasterDetailAsync(SelectedModel);', 'No Master 모델별 조회 호출')
    s = one(s, '''            var data = response.Data;
            if (data is null)''',
        '''            // 모델 변경 등으로 무효화된 응답은 UI에 반영하지 않습니다.
            if (requestVersion != System.Threading.Interlocked.Read(ref _requestVersion))
                return;

            var data = response?.Data;
            if (data is null)''', 'Detail 최신 응답만 적용')
    s = one(s, '''            _isNonMatchingTree = searchData == "non_matching";''',
        '''            _isNonMatchingTree = kind == "non_matching";''', 'Detail Tree 판별')
    s = one(s, '''        finally
        {
            IsLoading = false;
        }
    }''',
        '''        finally
        {
            if (requestVersion == System.Threading.Interlocked.Read(ref _requestVersion))
                IsLoading = false;
        }
    }''', 'Detail 요청 로딩 상태 관리')
    s = one(s, '''        foreach (var existing in ColumnFilters)
            existing.PropertyChanged -= OnFilterChanged;
        ColumnFilters.Clear();''',
        '''        ClearColumnFilters();''', 'Detail 필터 초기화 공통 함수')
    return s


def frontend_main_vm(s: str) -> str:
    s = one(s, '    private string _selectedFab;\n',
        '    private string _selectedFab;\n    private int _selectedTabIndex;\n', '메인 선택 탭 상태')
    return one(s, '    public UserSession Session { get; }',
        '''    /// <summary>탭 이동 시 실제 조회 시점에 맞춰 테이블 데이터를 갱신합니다.</summary>
    public int SelectedTabIndex
    {
        get => _selectedTabIndex;
        set
        {
            if (!SetProperty(ref _selectedTabIndex, value)) return;
            switch (value)
            {
                case 1: _ = NonMatchingRecipe.ActivateAsync(); break;
                case 2: _ = NoMasterRecipe.ActivateAsync(); break;
                case 3: _ = ExcludeRecipe.ActivateAsync(); break;
            }
        }
    }

    public UserSession Session { get; }''', '메인 선택 탭에서 자동 조회')


def frontend_main_xaml(s: str) -> str:
    return one(s, '<TabControl Margin="5">',
        '<TabControl Margin="5" SelectedIndex="{Binding SelectedTabIndex, Mode=TwoWay}">',
        '메인 탭 선택 바인딩')


def frontend_no_master_xaml(s: str) -> str:
    return one(s,
        '''            <StackPanel Grid.Column="1" Orientation="Horizontal" VerticalAlignment="Center">
                <Button Content="새로고침"''',
        '''            <StackPanel Grid.Column="1" Orientation="Horizontal" VerticalAlignment="Center">
                <TextBlock Text="Model" VerticalAlignment="Center" FontWeight="SemiBold" Margin="0,0,8,0" />
                <ComboBox Width="155" Margin="0,0,12,0"
                          ItemsSource="{Binding Models}"
                          SelectedItem="{Binding SelectedModel, Mode=TwoWay, UpdateSourceTrigger=PropertyChanged}"
                          ToolTip="Model 선택 시 No Master Recipe를 자동으로 조회합니다." />
                <Button Content="새로고침"''',
        'No Master 탭 상단 Model 콤보박스')


def frontend_new_master_vm(s: str) -> str:
    # 기존 Master 템플릿에는 allowed_values가 빠져 있어 ComboBox가 비는 문제를 함께 해결합니다.
    s = one(s,
        '''            foreach (var dto in templateResponse.Data?.Parameters ?? new List<MasterParameterDto>())
            {
                var item = MasterParameterItem.FromDto(dto, isEditMode: true);
                Parameters.Add(item);
            }

            StatusMessage = "신규 Master 생성 준비 완료";''',
        '''            foreach (var dto in templateResponse.Data?.Parameters ?? new List<MasterParameterDto>())
            {
                var option = ParameterOptions.FirstOrDefault(p =>
                    string.Equals(p.ParameterName, dto.ParameterName, StringComparison.OrdinalIgnoreCase));
                if (option is not null && dto.AllowedValues.Count == 0)
                    dto.AllowedValues = option.AllowedValues.ToList();
                var item = MasterParameterItem.FromDto(dto, isEditMode: true);
                Parameters.Add(item);
            }

            StatusMessage = Parameters.Count == 0
                ? "기존 Master 템플릿이 없습니다. 우측 Parameter 목록에서 필요한 항목을 추가하세요."
                : "신규 Master 생성 준비 완료";''',
        '신규 Master 템플릿 문자열 고유값 보완')
    return s


def server_master_data(s: str) -> str:
    # 기존 모델에 등록된 Master와 파싱 완료 Recipe를 함께 포함합니다.
    new_options = '''def master_filter_options(model: str) -> dict:
    """파싱 Recipe 및 기존 Master에서 선택 Model의 기준정보 선택지를 만든다."""
    options: dict[str, object] = {
        "tech_prod": [],
        "tech": [],
        "prod_group": [],
        "level_like": "",
        "layer_like": "",
    }
    if model != "PUMA":
        options["mode"] = []
    if not model:
        return options

    # Master가 없는 신규 Model도 화면에 선택지를 표시할 수 있어야 합니다.
    frame = PostgresCRUD.select_query(
        """
        SELECT tech_prod, tech, prod_group, level, layer, mode
        FROM dm_recipe_info
        WHERE model=%s AND is_remove=false
        UNION
        SELECT tech_prod, tech, prod_group, level, layer, mode
        FROM dm_master_recipe_info
        WHERE model=%s
        """,
        (model, model),
    )
    for column in ("tech_prod", "tech", "prod_group", "mode"):
        if column not in options:
            continue
        if frame.empty:
            continue
        series = frame[column]
        unique = set(series.dropna().astype(str).str.strip()) - {""}
        if series.isna().any():
            unique.add("NULL")
        options[column] = sorted(unique, key=str.casefold)
    return options


'''
    s = section(s, 'def master_filter_options(model: str) -> dict:\n',
                'def master_list(filters: dict | None = None) -> list[dict]:\n',
                new_options, 'Master 기준정보 선택지 파싱 Recipe 추가')
    new_params = '''def parameter_options(model: str) -> list[dict]:
    """파싱 Recipe를 기준으로 Parameter 명칭, 타입, 문자열 고유값을 일괄 조회한다.

    Master가 이미 존재하는 Model은 Master의 Parameter도 함께 포함합니다.
    문자열 고유값은 N+1 SQL이 아닌 단일 배치 조회로 읽습니다.
    """
    if not model:
        return []
    frame = PostgresCRUD.select_query(
        """
        WITH names AS (
            SELECT p.para_nm
            FROM dm_recipe_para p
            JOIN dm_recipe_info i ON i.recipe_key=p.recipe_key
            WHERE i.model=%s AND i.is_remove=false AND p.para_nm<>'mode'
            UNION
            SELECT p.para_nm
            FROM dm_master_recipe_para p
            JOIN dm_master_recipe_info i ON i.master_key=p.master_key
            WHERE i.model=%s AND p.para_nm<>'mode'
        )
        SELECT n.para_nm AS parameter_name,
               COALESCE(MAX(t.para_type), 'STRING') AS control_type
        FROM names n
        LEFT JOIN dm_para_type t ON t.para_nm=n.para_nm
        GROUP BY n.para_nm
        ORDER BY n.para_nm
        """,
        (model, model),
    )
    if frame.empty:
        return []
    result = frame.to_dict(orient="records")
    for item in result:
        item["control_type"] = str(item.get("control_type") or "STRING").upper()
        item["allowed_values"] = []
    string_names = [item["parameter_name"] for item in result
                    if item["control_type"] == "STRING"]
    if not string_names:
        return result

    # 하나의 모델에 대한 모든 문자열 파라미터 고유값을 한 번에 조회합니다.
    values = PostgresCRUD.select_query(
        """
        SELECT DISTINCT para_nm AS parameter_name, BTRIM(para_value) AS para_value
        FROM (
            SELECT p.para_nm, p.para_value
            FROM dm_recipe_para p
            JOIN dm_recipe_info i ON i.recipe_key=p.recipe_key
            WHERE i.model=%s AND i.is_remove=false AND p.para_nm = ANY(%s)
            UNION
            SELECT p.para_nm, p.para_value
            FROM dm_master_recipe_para p
            JOIN dm_master_recipe_info i ON i.master_key=p.master_key
            WHERE i.model=%s AND p.para_nm = ANY(%s)
        ) value_source
        WHERE para_value IS NOT NULL AND BTRIM(para_value) <> ''
        ORDER BY parameter_name, para_value
        """,
        (model, string_names, model, string_names),
    )
    by_name: dict[str, list[str]] = {name: [] for name in string_names}
    for row in values.to_dict(orient="records"):
        name = row["parameter_name"]
        if name in by_name:
            by_name[name].append(row["para_value"])
    for item in result:
        item["allowed_values"] = by_name.get(item["parameter_name"], [])
    return result


'''
    s = section(s, 'def parameter_options(model: str) -> list[dict]:\n',
                'def default_new_master_template(model: str) -> dict:\n',
                new_params, 'Master Parameter 조회 경로 변경')
    return s


def server_no_master_route(s: str) -> str:
    return one(s,
        '''        SELECT DISTINCT dmr.model 
        FROM dm_matching_rate dmr 
        ORDER BY dmr.model''',
        '''        SELECT model FROM (
            SELECT model FROM dm_recipe_info WHERE is_remove=false
            UNION
            SELECT model FROM dm_matching_rate
        ) models
        WHERE model IS NOT NULL AND BTRIM(model) <> ''
        ORDER BY model''',
        'No Master 모델 목록에 파싱 Recipe 포함')


def server_no_master_data(s: str) -> str:
    # FAB2의 반환 형식이 FAB1과 달라 데이터 0건에서 unpack 예외가 발생하는 문제 수정.
    if 'return pd.DataFrame(\n            columns=id_columns + ["master_group"] + master_columns + params\n        )' in s:
        s = one(s,
            '''        return pd.DataFrame(
            columns=id_columns + ["master_group"] + master_columns + params
        )''',
            '''        return pd.DataFrame(
            columns=id_columns + ["master_group"] + master_columns + params
        ), (id_columns, master_columns, params)''',
            'FAB2 No Master 비어 있는 데이터 반환 형식')
    elif '        ), ([], [], [])' in s:
        s = one(s, '        ), ([], [], [])',
            '        ), (id_columns, master_columns, params)', 'FAB1 No Master 0건 메타데이터 보존')
    else:
        raise ValueError('No Master 0건 반환 코드가 예상한 형태가 아닙니다.')

    return one(s,
        '''    frame["master_group"] = "Group_" + frame.groupby(master_columns).ngroup().apply(
        lambda x: f"{x+1:02d}"
    )''',
        '''    # null 기준정보가 있어도 그룹 번호가 NaN/float가 되지 않도록 처리합니다.
    group_numbers = frame.groupby(master_columns, dropna=False).ngroup()
    frame["master_group"] = group_numbers.map(lambda n: f"Group_{int(n) + 1:02d}")''',
        'No Master NULL 그룹 번호 및 format d 오류 예방')


FRONT_PATCHES = {
    'Behaviors/DataGridTextColumnFormatBehavior.cs': frontend_format,
    'Services/DmRmsApiService.cs': frontend_api,
    'ViewModels/DetaliTableViewModel.cs': frontend_detail_vm,
    'ViewModels/MainViewModel.cs': frontend_main_vm,
    'ViewModels/NewMasterViewModel.cs': frontend_new_master_vm,
    'Views/NoMasterRecipeView.xaml': frontend_no_master_xaml,
    'MainWindow.xaml': frontend_main_xaml,
}
SERVER_PATCHES = {
    'src/data/master_data.py': server_master_data,
    'src/routes/no_master.py': server_no_master_route,
    'src/data/no_master_data.py': server_no_master_data,
}


def main() -> int:
    parser = argparse.ArgumentParser(description='DM RMS 리뉴얼 2차 패치')
    parser.add_argument('--root', required=True, type=Path, help='GitHub DMRMS_Renewal 루트 경로')
    parser.add_argument('--dry-run', action='store_true', help='모든 변경점을 점검하고 실제 파일은 변경하지 않음')
    args = parser.parse_args()
    root = args.root.resolve()
    if not (root / FRONT / 'DM_RMS.Wpf.csproj').is_file():
        parser.error('올바른 DMRMS_Renewal 폴더가 아닙니다.')
    changes: dict[Path, str] = {}
    for rel, operation in FRONT_PATCHES.items():
        file = FRONT / rel
        original = (root / file).read_text(encoding='utf-8-sig')
        changes[file] = operation(original)
    for fab in ('fab1', 'fab2'):
        for rel, operation in SERVER_PATCHES.items():
            file = SERVER / fab / rel
            original = (root / file).read_text(encoding='utf-8-sig')
            changes[file] = operation(original)
    package = Path(__file__).resolve().parent
    documentation = {
        Path('README.md'): package / 'repo_README.md',
        Path('2_server/fab1/README.md'): package / 'server_README.md',
        Path('2_server/fab2/README.md'): package / 'server_README.md',
        Path('docs/서버_운영_명령어.md'): package / 'docs/서버_운영_명령어.md',
    }
    for relative, source in documentation.items():
        destination = root / relative
        if relative.parts[0] == 'docs' and destination.exists():
            raise ValueError(f'문서가 이미 존재합니다. 수동으로 병합하세요: {relative}')
        changes[relative] = source.read_text(encoding='utf-8')
    print(f'[점검 성공] 변경 예정 파일 {len(changes)}개')
    for file in changes:
        print(' -', file)
    if args.dry_run:
        print('사전 검사만 수행했습니다. 파일은 수정되지 않았습니다.')
        return 0
    backup = root / f'.dmrms_patch_backup_v2_{datetime.now():%Y%m%d_%H%M%S}'
    # 사전 검증을 모두 통과한 뒤 변경 파일의 원본을 먼저 전부 백업합니다.
    for rel in changes:
        source = root / rel
        if not source.exists():
            continue
        backup_file = backup / rel
        backup_file.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, backup_file)
    touched: list[Path] = []
    try:
        for rel, content in changes.items():
            destination = root / rel
            destination.parent.mkdir(parents=True, exist_ok=True)
            temp_file = destination.with_suffix(destination.suffix + '.dmrms_v2_tmp')
            temp_file.write_text(content, encoding='utf-8')
            temp_file.replace(destination)
            touched.append(rel)
    except Exception:
        # 파일 쓰기가 실패하면 이미 변경한 모든 파일을 이전 버전으로 복원합니다.
        for rel in reversed(touched):
            original = backup / rel
            destination = root / rel
            if original.exists():
                shutil.copy2(original, destination)
            else:
                destination.unlink(missing_ok=True)
        raise
    print('[적용 성공] 원본 파일 백업:', backup)
    print('다음 단계: Windows에서 WPF 빌드 / fab1·fab2 서버의 DB 연동 테스트를 진행하세요.')
    return 0


if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except (ValueError, OSError) as exc:
        print('[패치 실패] 파일은 수정 전에 사전 검증을 수행했습니다:', exc, file=sys.stderr)
        raise SystemExit(1) from exc
