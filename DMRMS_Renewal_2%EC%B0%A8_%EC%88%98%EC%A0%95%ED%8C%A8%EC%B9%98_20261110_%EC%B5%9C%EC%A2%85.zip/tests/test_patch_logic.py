"""서버 실 DB 없이 실행 가능한 2차 패치 계약 및 SQL 결과 매핑 테스트."""
from __future__ import annotations

import importlib.util
from pathlib import Path
from types import SimpleNamespace

import pandas as pd

PATCH = Path(__file__).resolve().parents[1] / 'apply_patch.py'
spec = importlib.util.spec_from_file_location('dmrms_v2', PATCH)
module = importlib.util.module_from_spec(spec)
assert spec.loader is not None
spec.loader.exec_module(module)


def _fake_master_module():
    """동일한 함수 경계만 가진 축약 모듈로 교체 코드의 문법을 검증합니다."""
    original = '''from __future__ import annotations

def master_filter_options(model: str) -> dict:
    return {}

def master_list(filters: dict | None = None) -> list[dict]:
    return []

def parameter_options(model: str) -> list[dict]:
    return []

def default_new_master_template(model: str) -> dict:
    return {"parameters": []}
'''
    modified = module.server_master_data(original)
    compile(modified, 'master_data.py', 'exec')
    namespace = {'PostgresCRUD': None}
    exec(modified, namespace)
    return namespace


def test_master_options_can_load_from_recipe_without_master():
    api = _fake_master_module()
    class MockDB:
        @staticmethod
        def select_query(query, params):
            assert 'FROM dm_recipe_info' in query
            assert 'FROM dm_master_recipe_info' in query
            assert params == ('KLA2365', 'KLA2365')
            return pd.DataFrame([
                {'tech_prod': 'P1', 'tech': 'T1', 'prod_group': 'G1', 'mode': None},
                {'tech_prod': 'P2', 'tech': 'T1', 'prod_group': 'G1', 'mode': 'AUTO'},
            ])
    api['PostgresCRUD'] = MockDB
    result = api['master_filter_options']('KLA2365')
    assert result['tech_prod'] == ['P1', 'P2']
    assert result['tech'] == ['T1']
    assert result['mode'] == ['AUTO', 'NULL']
    assert result['level_like'] == ''


def test_parameter_values_batched_not_per_parameter():
    api = _fake_master_module()
    calls = []
    class MockDB:
        @staticmethod
        def select_query(query, params):
            calls.append((query, params))
            if 'WITH names AS' in query:
                return pd.DataFrame([
                    {'parameter_name': 'WIDTH', 'control_type': 'STRING'},
                    {'parameter_name': 'EDGE', 'control_type': 'INTEGER'},
                ])
            assert 'FROM dm_recipe_para p' in query
            assert params == ('KLA2365', ['WIDTH'], 'KLA2365', ['WIDTH'])
            return pd.DataFrame([
                {'parameter_name': 'WIDTH', 'para_value': 'W1'},
                {'parameter_name': 'WIDTH', 'para_value': 'W2'},
            ])
    api['PostgresCRUD'] = MockDB
    result = api['parameter_options']('KLA2365')
    assert len(calls) == 2
    assert result[0]['allowed_values'] == ['W1', 'W2']
    assert result[1]['allowed_values'] == []


def test_no_master_no_data_returns_same_tuple_shape_for_both_fabs():
    base = '''    if frame.empty:
        return pd.DataFrame(
            columns=id_columns + ["master_group"] + master_columns + params
        ){ending}
    frame["master_group"] = "Group_" + frame.groupby(master_columns).ngroup().apply(
        lambda x: f"{{x+1:02d}}"
    )
'''
    for ending in (', ([], [], [])', ''):
        output = module.server_no_master_data(base.format(ending=ending))
        assert '(id_columns, master_columns, params)' in output
        assert 'dropna=False' in output
        assert 'Group_' in output


def test_korean_readme_and_operation_guide_exist():
    root = Path(__file__).resolve().parents[1]
    assert '운영' in (root / 'README.md').read_text(encoding='utf-8')
    guide = (root / 'docs' / '서버_운영_명령어.md').read_text(encoding='utf-8')
    assert '--call src:create_app' in guide
    assert 'MatchingAggregator.run()' in guide
