"""Optional static contract checks for a patched checkout.

Run: python -m pytest tests/test_applied_contracts.py -q
Set DMRMS_REPO_ROOT to your patched repo root to run these checks.
"""
from __future__ import annotations

import os
from pathlib import Path
import xml.etree.ElementTree as ET

import pytest


@pytest.fixture(scope="module")
def root():
    value = os.environ.get('DMRMS_REPO_ROOT')
    if not value:
        pytest.skip('Set DMRMS_REPO_ROOT to the patched repository path')
    return Path(value)


def test_master_model_contract(root):
    base = root / '3_frontend/DM_RMS.Wpf'
    api = (base / 'Services/DmRmsApiService.cs').read_text(encoding='utf-8-sig')
    master = (base / 'ViewModels/MasterManagementViewModel.cs').read_text(encoding='utf-8-sig')
    creation = (base / 'ViewModels/NewMasterViewModel.cs').read_text(encoding='utf-8-sig')
    assert 'GetMasterModelOptionsAsync()' in api
    assert 'GetMasterFilterOptionsAsync(model)' in master
    assert 'requestFilters["model"]' in master
    assert 'Interlocked.Increment' in master
    assert 'CanCreateNewMaster' in master
    assert 'CreateMasterAsync(SelectedModel, request)' in creation
    assert 'criteria["model"] = SelectedModel;' in creation
    assert 'ResetFiltersCommand' not in master


def test_xaml_well_formed(root):
    base = root / '3_frontend/DM_RMS.Wpf/Views'
    for filename in ('MasterManagementView.xaml', 'NewMasterWindow.xaml', 'RecipeManagementView.xaml'):
        ET.parse(base / filename)
    view = (base / 'MasterManagementView.xaml').read_text(encoding='utf-8-sig')
    assert 'SelectedModel' in view and 'CanCreateNewMaster' in view


def test_backend_auth_no_mock(root):
    for fab in ('fab1','fab2'):
        p = root / '2_server' / fab
        auth = (p / 'src/routes/auth.py').read_text()
        assert 'MOCK_USERS' not in auth
        assert 'hash_password' in auth
        assert 'ON CONFLICT (user_id) DO NOTHING' in auth
        master = (p / 'src/data/master_data.py').read_text()
        assert 'WHERE i.model = %s' in master
