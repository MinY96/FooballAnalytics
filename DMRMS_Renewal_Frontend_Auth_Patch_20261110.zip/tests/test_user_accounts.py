"""No database needed: run with `python -m pytest tests/test_user_accounts.py -q`."""
from __future__ import annotations

import pathlib
import sys

# Both fab1 and fab2 bundle the identical password module.
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1] / 'server_files'))

from src.services.user_accounts import hash_password, verify_password


def test_hash_and_verify():
    stored = hash_password('correct-1234')
    assert stored.startswith('pbkdf2_sha256$600000$')
    assert verify_password('correct-1234', stored)
    assert not verify_password('incorrect', stored)
    assert hash_password('correct-1234') != stored  # unique random salt


def test_invalid_password_and_hash():
    for value in ('', 'short12', 'x' * 129):
        try:
            hash_password(value)
        except ValueError:
            pass
        else:
            assert False, 'Should refuse invalid password length'
    for invalid in ('', 'not-a-hash', 'pbkdf2_sha256$0$AAA$BBB', 'xxx$600000$AAA$BBB'):
        assert not verify_password('password123', invalid)
