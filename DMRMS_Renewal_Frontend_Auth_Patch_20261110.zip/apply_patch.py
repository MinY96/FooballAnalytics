#!/usr/bin/env python3
"""Apply the 2026-11-10 DMRMS Renewal patch to a fresh repository checkout.

This script runs a complete preflight before modifying anything. Original changed
files are backed up to .dmrms_patch_backup_20261110 at the repository root.
"""
from __future__ import annotations

import argparse
import pathlib
import shutil
import sys

FRONT = pathlib.Path('3_frontend/DM_RMS.Wpf')
SERVER = pathlib.Path('2_server')
ROOT_MARKER = 'README.md'


def replace_one(text: str, old: str, new: str, label: str) -> str:
    count = text.count(old)
    if count != 1:
        raise ValueError(f'{label}: expected exactly one anchor, found {count}: {old[:110]!r}')
    return text.replace(old, new, 1)


def replace_segment(text: str, start: str, end: str, middle: str, label: str) -> str:
    a = text.count(start)
    b = text.count(end)
    if a != 1 or b != 1:
        raise ValueError(f'{label}: segment anchor not unique (start={a}, end={b})')
    before, after = text.split(start, 1)
    _, tail = after.split(end, 1)
    return before + middle + end + tail


def update_service(s: str) -> str:
    s = replace_one(s,
        'public Task<ApiResponse<JsonElement>> GetMasterFilterOptionsAsync()\n        => _api.GetAsync<JsonElement>("/api/master/filter-options");',
        '''public Task<ApiResponse<List<string>>> GetMasterModelOptionsAsync()
        => _api.GetAsync<List<string>>("/api/master/models");

    public Task<ApiResponse<JsonElement>> GetMasterFilterOptionsAsync(string model)
        => _api.GetAsync<JsonElement>($"/api/master/filter-options?model={Uri.EscapeDataString(model)}");''', 'service master options')
    s = replace_one(s,
        'public Task<ApiResponse<List<MasterParameterDto>>> GetMasterParameterOptionsAsync()\n        => _api.GetAsync<List<MasterParameterDto>>("/api/master/parameters/options");',
        '''public Task<ApiResponse<List<MasterParameterDto>>> GetMasterParameterOptionsAsync(string model)
        => _api.GetAsync<List<MasterParameterDto>>($"/api/master/parameters/options?model={Uri.EscapeDataString(model)}");''', 'service parameter options')
    s = replace_one(s,
        'public Task<ApiResponse<MasterDetailResponse>> GetNewMasterTemplateAsync()\n        => _api.GetAsync<MasterDetailResponse>("/api/master/template");',
        '''public Task<ApiResponse<MasterDetailResponse>> GetNewMasterTemplateAsync(string model)
        => _api.GetAsync<MasterDetailResponse>($"/api/master/template?model={Uri.EscapeDataString(model)}");''', 'service template')
    s = replace_one(s,
        'public Task<ApiResponse<JsonElement>> CreateMasterAsync(MasterCreateRequest request)\n        => _api.PostAsync<JsonElement>("/api/master/create", request);',
        '''public Task<ApiResponse<JsonElement>> CreateMasterAsync(string model, MasterCreateRequest request)
        => _api.PostAsync<JsonElement>($"/api/master/create?model={Uri.EscapeDataString(model)}", request);''', 'service create')
    return s


def update_master_vm(s: str) -> str:
    s = replace_one(s, '    private string _statusMessage = "준비";\n', '', 'remove dead status field')
    s = replace_one(s, '    private string _selectedMasterKey = string.Empty;',
        '''    private string _selectedMasterKey = string.Empty;
    private string _selectedModel = string.Empty;
    private long _filterRequestVersion;''', 'master state')
    s = replace_one(s, 'LoadFilterOptionsCommand = new AsyncRelayCommand(_ => LoadFilterOptionsAsync());',
        'LoadFilterOptionsCommand = new AsyncRelayCommand(_ => LoadModelsAsync());', 'refresh model options')
    s = replace_one(s, '        ResetFiltersCommand = new RelayCommand(_ => ResetFilters());\n', '', 'remove reset command initializer')
    s = replace_one(s,
        'OpenNewMasterCommand = new AsyncRelayCommand(_ => OpenNewMasterAsync(), _ => CanManageMaster);',
        'OpenNewMasterCommand = new AsyncRelayCommand(_ => OpenNewMasterAsync(), _ => CanCreateNewMaster);', 'model required for create command')
    s = replace_one(s, '        _ = LoadFilterOptionsAsync();\n    }',
        '        _ = LoadModelsAsync();\n    }', 'constructor single load')
    s = replace_one(s, '    public IReadOnlyList<string> FabOptions { get; } = new[] { "fab1", "fab2" };\n',
        '    public ObservableCollection<string> Models { get; } = new();\n', 'models collection')
    s = replace_one(s,
        '''    public string SelectedFab
    {
        get => _selectedFab;
        set
        {
            if (SetProperty(ref _selectedFab, value))
            {
                _ = LoadFilterOptionsAsync();
            }
        }
    }

    public string SelectedMasterKey''',
        '''    public string SelectedFab
    {
        get => _selectedFab;
        set => SetProperty(ref _selectedFab, value); // 사업장은 로그인 세션에 귀속됩니다.
    }

    public string SelectedModel
    {
        get => _selectedModel;
        set
        {
            if (SetProperty(ref _selectedModel, value ?? string.Empty))
            {
                OnPropertyChanged(nameof(CanCreateNewMaster));
                ((AsyncRelayCommand)OpenNewMasterCommand).RaiseCanExecuteChanged();
                _ = LoadFilterOptionsAsync();
            }
        }
    }

    public bool CanCreateNewMaster => CanManageMaster && !string.IsNullOrWhiteSpace(SelectedModel);

    public string SelectedMasterKey''', 'fab and model properties')
    s = replace_one(s, '    public ICommand ResetFiltersCommand { get; }\n', '', 'remove reset command property')
    code = '''    /// <summary>선택 가능한 Model을 최초 한 번 조회하고, 새로고침 시 기존 선택을 보존합니다.</summary>
    private async Task LoadModelsAsync()
    {
        try
        {
            var previousModel = SelectedModel;
            var response = await _api.GetMasterModelOptionsAsync();
            var names = (response.Data ?? new List<string>())
                .Where(x => !string.IsNullOrWhiteSpace(x))
                .Distinct(StringComparer.OrdinalIgnoreCase)
                .OrderBy(x => x, StringComparer.OrdinalIgnoreCase)
                .ToList();

            Models.Clear();
            foreach (var name in names)
                Models.Add(name);

            if (!names.Contains(previousModel, StringComparer.OrdinalIgnoreCase))
                SelectedModel = string.Empty;
            else
                await LoadFilterOptionsAsync();
        }
        catch (Exception ex)
        {
            _dialog.ShowError(ex.Message);
        }
    }

    /// <summary>
    /// Model 변경 시 즉시 현재 화면을 초기화합니다. 오래된 비동기 응답은
    /// 세대 번호를 검사해 폐기하므로 FAB2의 필터 중복도 발생하지 않습니다.
    /// </summary>
    private async Task LoadFilterOptionsAsync()
    {
        var generation = System.Threading.Interlocked.Increment(ref _filterRequestVersion);
        var model = SelectedModel;
        Filters.Clear();
        ClearMasterListColumnFilters();
        MasterListView = null;
        MasterParameters.Clear();
        SelectedMasterKey = string.Empty;
        IsEditMode = false;

        if (string.IsNullOrWhiteSpace(model)) return;

        try
        {
            var response = await _api.GetMasterFilterOptionsAsync(model);
            if (generation != System.Threading.Interlocked.Read(ref _filterRequestVersion)
                || !string.Equals(SelectedModel, model, StringComparison.OrdinalIgnoreCase))
                return;

            if (response.Data.ValueKind != JsonValueKind.Object) return;

            // _like 여부가 다른 동일 기준정보 및 서버의 중복 옵션을 정규화합니다.
            var seenKeys = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            var orderedProperties = response.Data.EnumerateObject()
                .OrderBy(property => GetFilterOrder(property.Name))
                .ThenBy(property => property.Name, StringComparer.OrdinalIgnoreCase);

            foreach (var property in orderedProperties)
            {
                var normalizedKey = property.Name.Replace("_like", string.Empty, StringComparison.OrdinalIgnoreCase);
                if (string.Equals(normalizedKey, "model", StringComparison.OrdinalIgnoreCase)
                    || !seenKeys.Add(normalizedKey))
                    continue;

                var item = new MasterFilterItem
                {
                    Key = property.Name,
                    DisplayName = ToDisplayName(property.Name),
                    IsLikeFilter = property.Name.EndsWith("_like", StringComparison.OrdinalIgnoreCase)
                };

                if (property.Value.ValueKind == JsonValueKind.Array)
                {
                    item.Options.Add(string.Empty);
                    foreach (var option in property.Value.EnumerateArray()
                        .Select(x => x.ValueKind == JsonValueKind.Null ? string.Empty : x.ToString())
                        .Where(x => !string.IsNullOrWhiteSpace(x))
                        .Distinct(StringComparer.OrdinalIgnoreCase))
                        item.Options.Add(option);
                }
                Filters.Add(item);
            }
        }
        catch (Exception ex)
        {
            if (generation == System.Threading.Interlocked.Read(ref _filterRequestVersion))
                _dialog.ShowError(ex.Message);
        }
    }

'''
    s = replace_segment(s, '    private async Task LoadFilterOptionsAsync()\n    {',
        '    private async Task SearchMasterListAsync()', code, 'replace master filters load')
    s = replace_one(s,
        '''        try
        {
            var response = await _api.GetMasterListAsync(new MasterListRequest { Filters = BuildFilterRequest() });
            var table = response.Data?.ToDataTable();''',
        '''        if (string.IsNullOrWhiteSpace(SelectedModel))
        {
            _dialog.ShowInfo("조회할 Model을 먼저 선택하세요.");
            return;
        }

        var requestedModel = SelectedModel;
        var requestFilters = BuildFilterRequest();
        requestFilters["model"] = new Dictionary<string, string>
        {
            ["mode"] = "equals",
            ["value"] = requestedModel
        };
        try
        {
            var response = await _api.GetMasterListAsync(new MasterListRequest { Filters = requestFilters });
            if (!string.Equals(requestedModel, SelectedModel, StringComparison.OrdinalIgnoreCase))
                return;
            var table = response.Data?.ToDataTable();''', 'enforce model in search')
    s = replace_one(s,
        '''        if (!CanManageMaster)
        {
            _dialog.ShowInfo("신규 Master 생성은 관리자 계정에서만 사용할 수 있습니다.");
            return;
        }

        try
        {
            var viewModel = new NewMasterViewModel(_api, _dialog, Filters);''',
        '''        if (!CanCreateNewMaster)
        {
            _dialog.ShowInfo("관리자 권한과 Model 선택이 필요합니다.");
            return;
        }

        try
        {
            var viewModel = new NewMasterViewModel(_api, _dialog, Filters, SelectedModel);''', 'new master selected model')
    s = replace_segment(s,'    private void ResetFilters()\n    {','    private void SetEditMode(bool enabled)', '', 'remove reset handler')
    # Remove the obsolete, fully commented-out implementation of local header filters.
    start = s.find('        //foreach (var filter in MasterListColumnFilters)')
    if start < 0:
        raise ValueError('master VM: obsolete commented code anchor missing')
    end = s.find('        ClearMasterListColumnFilters();', start)
    if end < 0:
        raise ValueError('master VM: filter implementation anchor missing')
    s = s[:start] + s[end:]
    return s


def update_master_xaml(s: str) -> str:
    s = replace_one(s, '''                    <Button Content="필터 새로고침" Command="{Binding LoadFilterOptionsCommand}" />
                    <Button Content="신규 Master 생성" IsEnabled="{Binding CanManageMaster}" ToolTip="관리자 계정에서만 사용할 수 있습니다." Style="{StaticResource SoftPrimaryButtonStyle}" Command="{Binding OpenNewMasterCommand}" />''',
    '''                    <TextBlock Text="Model" VerticalAlignment="Center" Margin="0,0,8,0" FontWeight="SemiBold" />
                    <ComboBox Width="155" Margin="0,0,8,0"
                              ItemsSource="{Binding Models}"
                              SelectedItem="{Binding SelectedModel, Mode=TwoWay, UpdateSourceTrigger=PropertyChanged}"
                              ToolTip="Model을 선택하면 기준정보 필터가 자동으로 초기화됩니다." />
                    <Button Content="필터 새로고침" Command="{Binding LoadFilterOptionsCommand}" />
                    <Button Content="신규 Master 생성" IsEnabled="{Binding CanCreateNewMaster}" ToolTip="Model 선택 및 관리자 권한이 필요합니다." Style="{StaticResource SoftPrimaryButtonStyle}" Command="{Binding OpenNewMasterCommand}" />''', 'master top model selector')
    s = replace_one(s, '                    <Button Content="초기화" Command="{Binding ResetFiltersCommand}" />\n', '', 'remove master filter reset button')
    return s


def update_new_master_vm(s: str) -> str:
    s = replace_one(s,
        '''        IDialogService dialog,
        IEnumerable<MasterFilterItem> sourceFilters)
    {
        _api = api;
        _dialog = dialog;
''',
        '''        IDialogService dialog,
        IEnumerable<MasterFilterItem> sourceFilters,
        string selectedModel)
    {
        _api = api;
        _dialog = dialog;
        SelectedModel = selectedModel;
''', 'newMaster ctor model')
    s = replace_one(s, '    public ObservableCollection<MasterFilterItem> Criteria { get; }',
        '    public string SelectedModel { get; }\n\n    public ObservableCollection<MasterFilterItem> Criteria { get; }', 'newMaster model property')
    s = replace_one(s, '_api.GetMasterParameterOptionsAsync();', '_api.GetMasterParameterOptionsAsync(SelectedModel);', 'parameter selection by model')
    s = replace_one(s, '_api.GetNewMasterTemplateAsync();', '_api.GetNewMasterTemplateAsync(SelectedModel);', 'template by model')
    s = replace_one(s, '    private async Task CreateMasterAsync()\n    {\n        try',
        '''    private async Task CreateMasterAsync()
    {
        if (string.IsNullOrWhiteSpace(SelectedModel))
        {
            _dialog.ShowInfo("Model 선택이 필요합니다.");
            return;
        }
        try''', 'newMaster create guard')
    s = replace_one(s, '''            if (criteria.Count == 0)
            {
                _dialog.ShowInfo("좌측 기준정보를 하나 이상 입력하세요.");
                return;
            }

            var request''',
        '''            if (criteria.Count == 0)
            {
                _dialog.ShowInfo("좌측 기준정보를 하나 이상 입력하세요.");
                return;
            }
            // Model은 상위 화면에서 선택한 값으로 고정하며, 팝업에서 수정하지 않습니다.
            criteria["model"] = SelectedModel;

            var request''', 'model criterion')
    s = replace_one(s,'_api.CreateMasterAsync(request);', '_api.CreateMasterAsync(SelectedModel, request);', 'create model query')
    s = replace_one(s,
        '''        foreach (var source in sourceFilters)
        {
            var clone = new MasterFilterItem''',
        '''        var seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        foreach (var source in sourceFilters)
        {
            var key = source.Key.Replace("_like", string.Empty, StringComparison.OrdinalIgnoreCase);
            if (string.Equals(key, "model", StringComparison.OrdinalIgnoreCase) || !seen.Add(key))
                continue;

            var clone = new MasterFilterItem''', 'newMaster criteria de-dup')
    return s


def update_new_master_xaml(s: str) -> str:
    s = replace_one(s,
        '        <TextBlock DockPanel.Dock="Top" Text="{Binding StatusMessage}" Margin="0,0,0,8" Foreground="Gray" />',
        '''        <StackPanel DockPanel.Dock="Top" Orientation="Horizontal" Margin="0,0,0,8">
            <TextBlock Text="선택 Model: " FontWeight="SemiBold" VerticalAlignment="Center" />
            <TextBlock Text="{Binding SelectedModel}" FontWeight="Bold" Foreground="{StaticResource PrimaryBrush}" VerticalAlignment="Center" />
            <TextBlock Text="{Binding StatusMessage}" Margin="20,0,0,0" Foreground="Gray" VerticalAlignment="Center" />
        </StackPanel>''', 'popup model text')
    return s


def update_recipe_xaml(s: str) -> str:
    # The current API no longer returns no_master in equipment-summary. Hide it if
    # an older server provides it during a staggered deployment.
    s = replace_one(s,
        'bh:DataGridHiddenColumnsBehavior.HiddenColumns="internal_id,recipe_key"',
        'bh:DataGridHiddenColumnsBehavior.HiddenColumns="internal_id,recipe_key,no_master"',
        'equipment summary compatibility')
    return s


def update_recipe_vm(s: str) -> str:
    s = replace_one(s,
        '    public static readonly string[] RecipeListHiddenColumns = { "internal_id", "recipe_key", "no_master" };',
        '''    public static readonly string[] RecipeListHiddenColumns = { "internal_id", "recipe_key", "no_master" };
    public static readonly string[] EquipmentSummaryHiddenColumns = { "internal_id", "recipe_key", "no_master" };''', 'summary hidden for exports')
    s = replace_one(s, 'DataTableExportHelper.CopyToClipboard(EquipmentSummaryView)',
        'DataTableExportHelper.CopyToClipboard(EquipmentSummaryView, EquipmentSummaryHiddenColumns)', 'copy equipment summary')
    s = replace_one(s,
        'ExportExcel(EquipmentSummaryView, "equipment_summary.xlsx", "EquipmentSummary")',
        'ExportExcel(EquipmentSummaryView, "equipment_summary.xlsx", "EquipmentSummary", EquipmentSummaryHiddenColumns)',
        'export equipment summary')
    return s


def update_master_data(s: str) -> str:
    s = replace_one(s,
        '''        WHERE p.master_key like %s
            AND\tp.master_key=(
                SELECT master_key 
                FROM dm_master_recipe_info 
                ORDER BY master_key DESC 
                LIMIT 1
            )''',
        '''        WHERE p.master_key = (
            SELECT i.master_key
            FROM dm_master_recipe_info i
            WHERE i.model = %s
            ORDER BY i.master_key DESC
            LIMIT 1
        )''', 'fix latest template model')
    s = replace_one(s, '        (f"{model}%",),\n    ).to_dict(orient="records")\n    return {"parameters": rows}',
        '        (model,),\n    ).to_dict(orient="records")\n    return {"parameters": rows}', 'template SQL parameter')
    s = replace_one(s,
        '''    if model != "PUMA":
        require_criteria = REQUIRED_CRITERIA_KLA''',
        '''    if not model:
        raise ValueError("Model을 선택해야 Master Recipe를 생성할 수 있습니다.")
    if criteria.get("model") != model:
        raise ValueError("선택 Model과 요청 기준정보의 Model이 일치하지 않습니다.")
    if model != "PUMA":
        require_criteria = REQUIRED_CRITERIA_KLA''', 'create model consistency')
    return s


def update_master_route(s: str) -> str:
    s = replace_one(s,
        '''        SELECT DISTINCT dmr.model 
        FROM dm_matching_rate dmr 
        ORDER BY dmr.model''',
        '''        SELECT model FROM (
            SELECT model FROM dm_matching_rate
            UNION
            SELECT model FROM dm_master_recipe_info
        ) t
        WHERE model IS NOT NULL AND BTRIM(model) <> ''
        ORDER BY model''', 'model endpoint include masters')
    return s


FRONT_PATCHES = {
    'Services/DmRmsApiService.cs': update_service,
    'ViewModels/MasterManagementViewModel.cs': update_master_vm,
    'Views/MasterManagementView.xaml': update_master_xaml,
    'ViewModels/NewMasterViewModel.cs': update_new_master_vm,
    'Views/NewMasterWindow.xaml': update_new_master_xaml,
    'Views/RecipeManagementView.xaml': update_recipe_xaml,
    'ViewModels/RecipeManagementViewModel.cs': update_recipe_vm,
}
SERVER_PATCHES = {'src/data/master_data.py': update_master_data,
                  'src/routes/master.py': update_master_route}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', required=True, type=pathlib.Path, help='DMRMS_Renewal Git repository root')
    parser.add_argument('--dry-run', action='store_true', help='only validate anchors and planned changes')
    args = parser.parse_args()
    root = args.root.resolve()
    pkg = pathlib.Path(__file__).resolve().parent
    if not (root / FRONT / 'DM_RMS.Wpf.csproj').exists():
        parser.error(f'Not a DMRMS_Renewal checkout: {root}')

    changed = {}
    for rel, patch in FRONT_PATCHES.items():
        path = FRONT / rel
        original = (root / path).read_text(encoding='utf-8-sig')
        changed[path] = patch(original)
    for fab in ('fab1', 'fab2'):
        for rel, patch in SERVER_PATCHES.items():
            path = SERVER / fab / rel
            original = (root / path).read_text(encoding='utf-8-sig')
            changed[path] = patch(original)

    additions = {}
    for fab in ('fab1','fab2'):
        for filename in ('src/routes/auth.py','src/services/user_accounts.py','scripts/bootstrap_admin.py'):
            dest = SERVER / fab / filename
            addition = pkg / 'server_files' / filename
            additions[dest] = addition.read_text(encoding='utf-8')
    for filename in ('fab1_dm_users.sql','fab2_dm_users.sql'):
        additions[pathlib.Path('db_migrations') / filename] = (pkg / 'db_migrations' / filename).read_text(encoding='utf-8')

    # Writing a new table/auth module over an existing independently evolved
    # version is risky. Existing identical content is fine, other content fails.
    for path, content in additions.items():
        full = root / path
        if full.exists() and path.name != 'auth.py':
            if full.read_text(encoding='utf-8-sig') != content:
                raise ValueError(f'Refusing to overwrite a different existing file: {path}')
        if path.name == 'auth.py' and 'MOCK_USERS' not in full.read_text(encoding='utf-8-sig'):
            raise ValueError(f'Auth route already changed; refusing overwrite: {path}')

    print(f'Preflight passed: {len(changed)} patches + {len(additions)} new/replacement files')
    for path in list(changed) + list(additions):
        print('  ' + str(path))
    if args.dry_run:
        print('Dry run only; no files were changed.')
        return 0

    backup_root = root / '.dmrms_patch_backup_20261110'
    if backup_root.exists():
        raise FileExistsError(f'Backup folder exists, refusing to rerun: {backup_root}')
    try:
        for rel, output in {**changed, **additions}.items():
            dest = root / rel
            dest.parent.mkdir(parents=True, exist_ok=True)
            if dest.exists():
                backup_path = backup_root / rel
                backup_path.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(dest, backup_path)
            temp_path = dest.with_suffix(dest.suffix + '.dmrms_patch_tmp')
            try:
                temp_path.write_text(output, encoding='utf-8')
                temp_path.replace(dest)
            finally:
                temp_path.unlink(missing_ok=True)
    except Exception:
        print('Error during writing; restore originals from:', backup_root, file=sys.stderr)
        raise
    print('Patch applied. Backups:', backup_root)
    print('NEXT: deploy db_migrations SQL and create admin before switching backend authentication.')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
