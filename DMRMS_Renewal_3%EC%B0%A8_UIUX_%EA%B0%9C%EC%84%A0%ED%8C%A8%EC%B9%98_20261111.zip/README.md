# DM RMS 리뉴얼 — 3차 UI/UX 개선 패치

**적용 대상:** `https://github.com/MinY96/DMRMS_Renewal.git`  
**작업 기준:** 2026-11-11 확인한 GitHub `master` 커밋 `e2086fb6963a0655b4a9ed32d0da6b499134595e` 기준.  
**변경 범위:** `3_frontend/DM_RMS.Wpf`의 WPF 소스 및 변경 내역 문서. `1_backup`, `2_server`는 수정하지 않습니다.

## 1. 수정 사항

사용자가 요청한 8개 UI/UX 개선을 적용합니다.

1. Master 관리 탭: 선택 Model 표시, 기준정보 로딩 표시, 로딩 중 조회 버튼 비활성화
2. Master 필터: 3열 균등 레이아웃과 입력 컨트롤 너비 통일
3. 신규 Master: 필수 기준정보를 인라인으로 검증하고 유효한 상태에서만 생성 버튼 활성화
4. Recipe 처리: 백업·삭제의 성공/실패/미처리·확인 필요 건수 표시, 행별 결과 표시, 부분 성공 후 성공 삭제 항목만 갱신
5. Recipe 패널: 좌측/우측 너비 조절 슬라이더와 최소·최대 크기 제한
6. 공통 서비스: 로그인·신규 등록의 로딩 상태와 오류 처리를 `UiOperationRunner` 및 `IDialogService`로 통일
7. Master 저장: 변경 Parameter 건수, 저장 전 기존값·변경값을 확인하는 별도 미리보기 창
8. ComboBox: 전역 스타일로 선택 값 및 드롭다운 항목의 수직 중앙 정렬

자세한 내용은 `docs/3차_UIUX_변경사항.md`를 참고하세요.

## 2. 적용 전 준비

프로젝트를 **테스트용 로컬 폴더**에 복제하고 최신 `master`를 내려받습니다.

```powershell
# Windows PowerShell
cd D:\DM

git clone https://github.com/MinY96/DMRMS_Renewal.git
cd DMRMS_Renewal
git status
```

> GitHub 소스에 운영 DB 백업 파일이 포함되어 있을 수 있습니다. 공개 저장소로 운영 설비 데이터와 인증정보가 유출되지 않도록 확인하세요. 본 패치에는 실제 DB 데이터·계정이 포함되어 있지 않습니다.

## 3. 패치 적용

ZIP 압축을 해제한 폴더에서 다음 명령을 실행합니다. `--root`는 GitHub 프로젝트 최상위 폴더(`1_backup`, `2_server`, `3_frontend`가 있는 폴더)입니다.

```powershell
# 수정 위치를 검증하고 실제 소스는 변경하지 않습니다.
py -3.12 .\apply_patch.py --root "D:\DM\DMRMS_Renewal" --dry-run

# 문제없다면 실제 소스에 적용합니다.
py -3.12 .\apply_patch.py --root "D:\DM\DMRMS_Renewal"
```

변경 전에 기존 파일을 `<프로젝트 루트>\.dmrms_patch_backup_v3_날짜시간\` 경로에 복사합니다. 기존 코드를 보존한 후 새 파일을 쓰며, 중간 쓰기 실패 시 이미 변경한 파일을 복원합니다.

**다른 버전의 코드를 임의로 변경하지 않도록** 대상 문구가 정확히 한 번 나오는지 먼저 검사합니다. 패치 오류가 나면 최신 GitHub 코드와 충돌한 파일을 확인한 뒤 수정해야 합니다. 같은 패치를 두 번 적용하지 마세요.

## 4. 프론트엔드 빌드

Windows에서 .NET 8 SDK 및 Visual Studio WPF 빌드 도구를 설치한 환경이 필요합니다.

```powershell
cd D:\DM\DMRMS_Renewal

dotnet restore .\3_frontend\DM_RMS.Wpf.sln
dotnet build .\3_frontend\DM_RMS.Wpf.sln -c Release
```

컴파일이 정상적으로 완료되면 Visual Studio에서 실행 및 UI 검증 후 ClickOnce 배포를 진행하세요. .NET SDK가 없는 환경에서는 Python만으로 WPF 빌드 성공을 확인할 수 없습니다.

## 5. 수동 검증 우선순위

1. **Master 필터:** Model 선택 중 로딩 인디케이터가 보이고 조회 버튼이 비활성화되는지 확인
2. **신규 Master:** `KLA2139`, `KLA2365`, `PUMA` 각각 필수 기준정보 검증 및 생성 버튼 활성화 확인
3. **Master 편집:** Parameter 수정 → 미리보기 창에서 기존/변경값 확인 → 취소 시 저장 안 됨 → 확인 시 저장
4. **Recipe 백업:** 서버 `result.json` 개별 성공/실패 항목이 표시되는지 확인
5. **Recipe 삭제:** 성공으로 확인된 Recipe만 목록에서 제거하고 실패 항목이 남는지 확인 (테스트 장비만 사용)
6. **패널/콤보:** 사이드 패널 너비 조절, 모든 콤보박스 선택 텍스트 수직 중앙 정렬 확인
7. **권한:** 사용자 계정의 Master 수정·삭제·신규 생성, Recipe 삭제 버튼이 계속 비활성화되는지 확인

## 6. 원본 복구

패치 적용 시 출력된 `.dmrms_patch_backup_v3_*` 폴더의 파일을 원래 위치로 복사합니다. 새로 추가된 미리보기 UI 파일과 `UiOperationRunner.cs` 등은 제거해야 이전 상태로 돌아갑니다. 적용 전 별도 Git 커밋을 해 두는 것이 가장 안전합니다.

## 7. 서버 운영 안내

이번 패치에는 API·DB·백업 로직의 수정이 없습니다. 기존 2차 패치에서 제공한 `docs/서버_운영_명령어.md`를 계속 사용하세요. 서버/클라이언트 통신 시 결과 ZIP의 `result.json` 구조는 현재 GitHub의 API 구현을 기준으로 사용합니다.

## 8. 검증상 한계

이번 패치는 코드·XAML 정적 검사와 기존 1·2차 패치 기반의 로컬 소스 적용 테스트로 구성했습니다. 이 환경에서는 실제 Windows WPF 빌드, Fab API 접속, PostgreSQL/장비 FTP 동작을 검증할 수 없습니다. 운영 배포 전에 위 수동 테스트를 수행해야 합니다.
