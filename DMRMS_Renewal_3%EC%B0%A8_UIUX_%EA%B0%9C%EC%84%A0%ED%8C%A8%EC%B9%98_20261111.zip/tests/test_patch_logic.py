"""별도 Windows 실행환경 없이 수행 가능한 3차 패치 정적 계약 테스트."""
from __future__ import annotations
import os
from pathlib import Path
import subprocess
import sys
import xml.etree.ElementTree as ET
import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import apply_patch as patch


def test_patch_file_targets_frontend_only():
    assert len(patch.FRONT_PATCHES) == 13
    assert all('2_server' not in p for p in patch.FRONT_PATCHES)
    assert all('1_backup' not in p for p in patch.FRONT_PATCHES)


def test_strict_anchor_validation():
    assert patch.once('a b c', 'b', 'B', 'single') == 'a B c'
    with pytest.raises(ValueError):
        patch.once('b b', 'b', 'B', 'double')
    with pytest.raises(ValueError):
        patch.once('a', 'b', 'B', 'missing')


def test_new_preview_window_xml_is_valid():
    doc = ET.parse(ROOT / 'extra/Views/MasterChangePreviewWindow.xaml')
    xml = ET.tostring(doc.getroot(), encoding='unicode')
    assert 'ConfirmCommand' in xml and 'CancelCommand' in xml
    assert 'OriginalValue' in xml and 'UpdatedValue' in xml


def test_status_contract_and_limits():
    src = Path(patch.__file__).read_text(encoding='utf-8')
    for keyword in ('LastSuccessCount', 'LastFailureCount', 'LastUnprocessedCount',
                    'ApplyOperationResults', 'RemoveDeletedRows(manifest.DeletedItems)',
                    'IsRecipeOperationRunning', 'Math.Clamp(value, 440, 850)',
                    'Math.Clamp(value, 470, 900)'):
        assert keyword in src


def test_common_async_runner():
    runner=(ROOT/'extra/Services/UiOperationRunner.cs').read_text(encoding='utf-8')
    assert 'finally' in runner and 'setBusy(false)' in runner
    assert 'dialogs.ShowError' in runner


def test_optional_source_preflight():
    """DMRMS_REPO_ROOT가 지정된 경우 실제 소스 위치를 dry-run으로 검사합니다."""
    location = os.environ.get('DMRMS_REPO_ROOT')
    if not location:
        pytest.skip('DMRMS_REPO_ROOT 미지정. 실제 소스 연동 테스트 생략.')
    result=subprocess.run(
        [sys.executable, str(ROOT/'apply_patch.py'),'--root',location,'--dry-run'],
        capture_output=True, text=True, encoding='utf-8', check=False)
    assert result.returncode == 0, result.stdout+'\n'+result.stderr
