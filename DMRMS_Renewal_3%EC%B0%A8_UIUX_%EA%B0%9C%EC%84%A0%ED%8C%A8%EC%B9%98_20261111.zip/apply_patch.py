#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""2026-11-11 DM RMS 3차 UI/UX 패치. GitHub master 전용, 원본 백업 후 파일 변경."""
from __future__ import annotations
import argparse
import shutil
import sys
from datetime import datetime
from pathlib import Path

FRONT = Path('3_frontend/DM_RMS.Wpf')


def once(s: str, before: str, after: str, label: str) -> str:
    count=s.count(before)
    if count != 1:
        raise ValueError(f'{label}: 고유 변경 위치를 찾지 못했습니다 (발견 {count}). 시작: {before[:85]!r}')
    return s.replace(before,after,1)


def section(s: str, start: str, end: str, replacement: str, label: str) -> str:
    if s.count(start)!=1 or s.count(end)!=1: raise ValueError(f'{label}: 경계가 고유하지 않습니다')
    a, b=s.split(start,1)
    _, c=b.split(end,1)
    return a+replacement+end+c


def theme(s: str)->str:
    s=once(s,
        '''    <Style TargetType="ComboBox">
        <Setter Property="MinHeight" Value="30" />
        <Setter Property="Padding" Value="6,3" />''',
        '''    <Style TargetType="ComboBox">
        <!-- 모든 기본/편집 가능 콤보박스의 콘텐츠 및 항목을 수직 중앙 정렬 -->
        <Setter Property="VerticalContentAlignment" Value="Center" />
        <Setter Property="MinHeight" Value="30" />
        <Setter Property="Padding" Value="6,3" />''','공통 ComboBox 스타일')
    return once(s,
        '    <Style TargetType="DataGrid">',
        '''    <Style TargetType="ComboBoxItem">
        <Setter Property="VerticalContentAlignment" Value="Center" />
    </Style>

    <Style TargetType="DataGrid">''',
        'ComboBoxItem 목록 수직 중앙 정렬')


def master_view(s: str)->str:
    s=once(s,
        '''                    <TextBlock Text="기준정보 조회 → Master 상세 확인 → 변경 Parameter만 저장 / 신규 Master 생성" Style="{StaticResource MutedTextStyle}" Margin="0,4,0,0" />''',
        '''                    <TextBlock Text="기준정보 조회 → Master 상세 확인 → 변경 Parameter만 저장 / 신규 Master 생성" Style="{StaticResource MutedTextStyle}" Margin="0,4,0,0" />
                    <TextBlock Text="{Binding SelectedModelDescription}" Style="{StaticResource MutedTextStyle}" Margin="0,3,0,0" />''',
        '상단 선택 모델 표시')
    s=once(s,
        '''                    <Button Content="필터 새로고침" Command="{Binding LoadFilterOptionsCommand}" />''',
        '''                    <Button Content="필터 새로고침" Command="{Binding LoadFilterOptionsCommand}" />''',
        '새로고침 유지') if False else s
    s=once(s,
        '''                    <Button Content="조회" Style="{StaticResource SoftPrimaryButtonStyle}" Command="{Binding SearchMasterListCommand}" />''',
        '''                    <StackPanel Orientation="Horizontal" VerticalAlignment="Center">
                        <ProgressBar Width="64" Height="5" Margin="0,0,8,0" IsIndeterminate="True"
                                     Visibility="{Binding IsLoadingFilters, Converter={StaticResource BooleanToVisibilityConverter}}" />
                        <TextBlock Text="{Binding FilterLoadingDescription}" VerticalAlignment="Center"
                                   Style="{StaticResource MutedTextStyle}" Margin="0,0,8,0" />
                        <Button Content="조회" Style="{StaticResource SoftPrimaryButtonStyle}"
                                Command="{Binding SearchMasterListCommand}" IsEnabled="{Binding CanSearchMasterList}" />
                    </StackPanel>''',
        '마스터 로딩 표시 및 조회 방지')
    s=once(s,
        '''                            <WrapPanel />''',
        '''                            <UniformGrid Columns="3" />''',
        '균등한 기준정보 필터 배치')
    s=once(s,
        '''                            <StackPanel Margin="0,0,18,8">''',
        '''                            <StackPanel Margin="0,0,14,8" MinWidth="145">''',
        '기준정보 필터 셀 배치')
    s=once(s,
        '''<ComboBox Width="145" ItemsSource="{Binding Options}" SelectedItem="{Binding SelectedValue}">''',
        '''<ComboBox MinWidth="135" HorizontalAlignment="Stretch" ItemsSource="{Binding Options}" SelectedItem="{Binding SelectedValue}">''',
        '기준정보 콤보 너비')
    s=once(s,
        '''<TextBox Width="145" Text="{Binding TextValue, UpdateSourceTrigger=PropertyChanged}">''',
        '''<TextBox MinWidth="135" HorizontalAlignment="Stretch" Text="{Binding TextValue, UpdateSourceTrigger=PropertyChanged}">''',
        '기준정보 텍스트 너비')
    s=once(s,
        '''                                <Button Content="저장" IsEnabled="{Binding CanManageMaster}" ToolTip="관리자 계정에서만 사용할 수 있습니다." Style="{StaticResource SoftPrimaryButtonStyle}" Command="{Binding SaveMasterDetailCommand}" />''',
        '''                                <Border Style="{StaticResource RowCountBadgeStyle}" Margin="0,0,6,0">
                                    <TextBlock Text="{Binding ChangedMasterCount, StringFormat='변경 {0:N0}건'}" />
                                </Border>
                                <Button Content="변경 미리보기 / 저장" IsEnabled="{Binding CanManageMaster}" ToolTip="변경 전후 값을 비교하고 저장을 확정합니다." Style="{StaticResource SoftPrimaryButtonStyle}" Command="{Binding SaveMasterDetailCommand}" />''',
        'Master 저장 미리보기 명시')
    # Master view의 리소스에 BooleanToVisibilityConverter가 선언되어 있는지 확인한다.
    if 'x:Key="BooleanToVisibilityConverter"' not in s:
        s=once(s, '''    <UserControl.Resources>''', '''    <UserControl.Resources>
        <BooleanToVisibilityConverter x:Key="BooleanToVisibilityConverter" />''', 'Master 리소스 converter')
    return s


def master_vm(s: str)->str:
    s=once(s,
        '''    private bool _isEditMode;''',
        '''    private bool _isEditMode;
    private bool _isLoadingFilters;''', 'Master 로딩 상태 필드')
    s=once(s,
        '''        SearchMasterListCommand = new AsyncRelayCommand(_ => SearchMasterListAsync());''',
        '''        SearchMasterListCommand = new AsyncRelayCommand(_ => SearchMasterListAsync(), _ => CanSearchMasterList);''',
        'Master 조회 명령 로딩 제한')
    s=once(s,
        '''        MasterParameters.CollectionChanged += (_, _) => OnPropertyChanged(nameof(MasterDetailRowCount));''',
        '''        MasterParameters.CollectionChanged += (_, e) =>
        {
            if (e.OldItems != null)
                foreach (MasterParameterItem item in e.OldItems)
                    item.PropertyChanged -= OnMasterParameterChanged;
            if (e.NewItems != null)
                foreach (MasterParameterItem item in e.NewItems)
                    item.PropertyChanged += OnMasterParameterChanged;
            OnPropertyChanged(nameof(MasterDetailRowCount));
            OnPropertyChanged(nameof(ChangedMasterCount));
        };''', '변경 건수 자동 추적')
    s=once(s,
        '''                OnPropertyChanged(nameof(CanCreateNewMaster));''',
        '''                OnPropertyChanged(nameof(CanCreateNewMaster));
                OnPropertyChanged(nameof(SelectedModelDescription));
                OnPropertyChanged(nameof(CanSearchMasterList));
                ((AsyncRelayCommand)SearchMasterListCommand).RaiseCanExecuteChanged();''',
        '선택 모델 상태 갱신')
    s=once(s,
        '''    public bool CanCreateNewMaster => CanManageMaster && !string.IsNullOrWhiteSpace(SelectedModel);''',
        '''    public bool CanCreateNewMaster => CanManageMaster && !string.IsNullOrWhiteSpace(SelectedModel);
    public string SelectedModelDescription => string.IsNullOrWhiteSpace(SelectedModel)
        ? "선택된 Model 없음 · 먼저 Model을 선택하세요."
        : $"현재 Model: {SelectedModel}";
    public bool IsLoadingFilters
    {
        get => _isLoadingFilters;
        private set
        {
            if (!SetProperty(ref _isLoadingFilters, value)) return;
            OnPropertyChanged(nameof(FilterLoadingDescription));
            OnPropertyChanged(nameof(CanSearchMasterList));
            ((AsyncRelayCommand)SearchMasterListCommand).RaiseCanExecuteChanged();
        }
    }
    public string FilterLoadingDescription => IsLoadingFilters ? "기준정보 불러오는 중..." : string.Empty;
    public bool CanSearchMasterList => !IsLoadingFilters && !string.IsNullOrWhiteSpace(SelectedModel);
    public int ChangedMasterCount => MasterParameters.Count(x => x.IsChanged);

    private void OnMasterParameterChanged(object? sender, PropertyChangedEventArgs e)
    {
        if (e.PropertyName == nameof(MasterParameterItem.IsChanged))
            OnPropertyChanged(nameof(ChangedMasterCount));
    }''',
        'Master 상태 + 변경 건수')
    s=once(s,
        '''        IsEditMode = false;

        if (string.IsNullOrWhiteSpace(model)) return;

        try
        {
            var response = await _api.GetMasterFilterOptionsAsync(model);''',
        '''        IsEditMode = false;
        // 이전 요청의 완료 이벤트는 generation 검사 후에만 현재 로딩 상태를 변경할 수 있습니다.
        IsLoadingFilters = !string.IsNullOrWhiteSpace(model);
        if (string.IsNullOrWhiteSpace(model)) return;

        try
        {
            var response = await _api.GetMasterFilterOptionsAsync(model);''',
        '조회 로딩 진입')
    s=once(s,
        '''        catch (Exception ex)
        {
            if (generation == System.Threading.Interlocked.Read(ref _filterRequestVersion))
                _dialog.ShowError(ex.Message);
        }
    }

    private async Task SearchMasterListAsync()''',
        '''        catch (Exception ex)
        {
            if (generation == System.Threading.Interlocked.Read(ref _filterRequestVersion))
                _dialog.ShowError(ex.Message);
        }
        finally
        {
            if (generation == System.Threading.Interlocked.Read(ref _filterRequestVersion))
                IsLoadingFilters = false;
        }
    }

    private async Task SearchMasterListAsync()''',
        '로딩 완료 시 버튼 복구')
    s=once(s,
        '''        if (string.IsNullOrWhiteSpace(SelectedModel))
        {
            _dialog.ShowInfo("조회할 Model을 먼저 선택하세요.");''',
        '''        if (IsLoadingFilters) return;
        if (string.IsNullOrWhiteSpace(SelectedModel))
        {
            _dialog.ShowInfo("조회할 Model을 먼저 선택하세요.");''',
        '조회 중 조회 중복 방지')
    s=once(s,
        '''            if (!_dialog.Confirm($"{SelectedMasterKey}의 변경된 Parameter {changedItems.Count}개를 저장하시겠습니까?"))
                return;''',
        '''            var preview = changedItems.Select(x => new MasterChangePreviewItem
            {
                ParameterName = x.ParameterName,
                OriginalValue = x.DisplayValue,
                UpdatedValue = x.GetCurrentValue()
            }).ToList();
            if (!_dialog.ConfirmMasterChanges(SelectedMasterKey, preview))
                return;''',
        '변경 전후 확인 모달')
    return s


def master_filter_model(s: str)->str:
    # 필수 검증은 팝업에서만 켜며 공통 필터 화면에는 영향이 없습니다.
    s=once(s, '''    public bool IsLikeFilter { get; set; }
    public ObservableCollection<string> Options { get; } = new();''',
        '''    public bool IsLikeFilter { get; set; }
    public bool IsRequired { get; set; }
    public bool IsMissingRequired => IsRequired && string.IsNullOrWhiteSpace(EffectiveValue);
    public ObservableCollection<string> Options { get; } = new();''', '필수 기준정보 메타데이터')
    s=once(s, '''        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(EffectiveValue)));
    }
}

public sealed class MasterParameterItem''',
        '''        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(EffectiveValue)));
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(IsMissingRequired)));
    }
}

public sealed class MasterParameterItem''', '필수 기준정보 오류 표기')
    return s


def new_master_vm(s: str)->str:
    s=once(s,
        '''    private string _statusMessage = "준비";''',
        '''    private string _statusMessage = "준비";
    private bool _isCreating;
    private bool _isInitialized;''',
        '신규 마스터 상태')
    s=once(s,
        '''        Criteria = new ObservableCollection<MasterFilterItem>(CloneCriteriaFilters(sourceFilters));
        Parameters = new ObservableCollection<MasterParameterItem>();''',
        '''        Criteria = new ObservableCollection<MasterFilterItem>(CloneCriteriaFilters(sourceFilters, selectedModel));
        foreach (var criterion in Criteria)
            criterion.PropertyChanged += (_, e) =>
            {
                if (e.PropertyName == nameof(MasterFilterItem.EffectiveValue))
                    RefreshCreationState();
            };
        Parameters = new ObservableCollection<MasterParameterItem>();
        Parameters.CollectionChanged += (_, _) => RefreshCreationState();''',
        '신규마스터 유효성 상태 구독')
    s=once(s,
        '''        CreateMasterCommand = new AsyncRelayCommand(_ => CreateMasterAsync());''',
        '''        CreateMasterCommand = new AsyncRelayCommand(_ => CreateMasterAsync(), _ => CanCreateMaster);''',
        '유효할 때 생성 명령 활성화')
    s=once(s,
        '''    public bool Created { get; private set; }''',
        '''    public bool Created { get; private set; }
    public bool HasMissingCriteria => Criteria.Any(x => x.IsMissingRequired);
    public bool CanCreateMaster => _isInitialized && !_isCreating
        && !string.IsNullOrWhiteSpace(SelectedModel)
        && !HasMissingCriteria && Parameters.Count > 0;
    public string CriteriaValidationMessage => HasMissingCriteria
        ? "* 표시 기준정보를 모두 입력하세요." : "필수 기준정보가 입력되었습니다.";

    private void RefreshCreationState()
    {
        OnPropertyChanged(nameof(HasMissingCriteria));
        OnPropertyChanged(nameof(CriteriaValidationMessage));
        OnPropertyChanged(nameof(CanCreateMaster));
        ((AsyncRelayCommand)CreateMasterCommand).RaiseCanExecuteChanged();
    }''',
        '인라인 필수값/생성 가능 상태')
    s=once(s,
        '''            StatusMessage = Parameters.Count == 0
                ? "기존 Master 템플릿이 없습니다. 우측 Parameter 목록에서 필요한 항목을 추가하세요."
                : "신규 Master 생성 준비 완료";''',
        '''            _isInitialized = true;
            RefreshCreationState();
            StatusMessage = Parameters.Count == 0
                ? "기존 Master 템플릿이 없습니다. 우측 Parameter 목록에서 필요한 항목을 추가하세요."
                : "신규 Master 생성 준비 완료";''',
        '모델/파라미터 로드 완료 알림')
    s=once(s,
        '''    private async Task CreateMasterAsync()
    {
        if (string.IsNullOrWhiteSpace(SelectedModel))''',
        '''    private async Task CreateMasterAsync()
    {
        if (HasMissingCriteria)
        {
            _dialog.ShowInfo("필수 기준정보를 모두 입력하세요.");
            return;
        }
        if (string.IsNullOrWhiteSpace(SelectedModel))''',
        '필수값 사전 점검')
    s=once(s,
        '''        try
        {
            if (Parameters.Count == 0)''',
        '''        _isCreating = true;
        RefreshCreationState();
        try
        {
            if (Parameters.Count == 0)''',
        '중복 생성 방지')
    s=once(s,
        '''        catch (Exception ex)
        {
            StatusMessage = "신규 Master 생성 실패";
            _dialog.ShowError(ex.Message);
        }
    }

    private static IEnumerable<MasterFilterItem> CloneCriteriaFilters(IEnumerable<MasterFilterItem> sourceFilters)''',
        '''        catch (Exception ex)
        {
            StatusMessage = "신규 Master 생성 실패";
            _dialog.ShowError(ex.Message);
        }
        finally
        {
            _isCreating = false;
            RefreshCreationState();
        }
    }

    private static IEnumerable<MasterFilterItem> CloneCriteriaFilters(IEnumerable<MasterFilterItem> sourceFilters, string model)''',
        '생성 중 버튼 비활성화')
    s=once(s,
        '''                IsLikeFilter = source.IsLikeFilter,
                TextValue = string.Empty,''',
        '''                IsLikeFilter = source.IsLikeFilter,
                IsRequired = key is "tech_prod" or "tech" or "prod_group" or "level" or "layer"
                    || (key == "mode" && !string.Equals(model, "PUMA", StringComparison.OrdinalIgnoreCase)),
                TextValue = string.Empty,''',
        'model별 필수 기준정보 정의')
    return s


def new_master_view(s: str)->str:
    s=once(s,
        '''    <Window.Resources>''',
        '''    <Window.Resources>
        <BooleanToVisibilityConverter x:Key="BooleanToVisibilityConverter" />''',
        '신규마스터 필수값 converter')
    s=once(s,
        '''            <Button Content="생성" Width="90" Height="32" Command="{Binding CreateMasterCommand}" />''',
        '''            <TextBlock Text="{Binding CriteriaValidationMessage}" Foreground="#A43A3A"
                       VerticalAlignment="Center" Margin="0,0,12,0" />
            <Button Content="생성" Width="90" Height="32" Command="{Binding CreateMasterCommand}"
                    IsEnabled="{Binding CanCreateMaster}" />''',
        '인라인 생성 가능 여부')
    s=once(s,
        '''                                    <TextBlock Text="{Binding DisplayName}" Margin="0,0,0,3" />''',
        '''                                    <StackPanel Orientation="Horizontal" Margin="0,0,0,3">
                                        <TextBlock Text="{Binding DisplayName}" />
                                        <TextBlock Text=" *" Foreground="#B91C1C" FontWeight="Bold"
                                                   Visibility="{Binding IsRequired, Converter={StaticResource BooleanToVisibilityConverter}}" />
                                    </StackPanel>''',
        '기준정보 필수 별표')
    s=once(s,
        '''                                    </TextBox>
                                </StackPanel>''',
        '''                                    </TextBox>
                                    <TextBlock Text="필수 입력" Foreground="#B91C1C" FontSize="11"
                                               Visibility="{Binding IsMissingRequired, Converter={StaticResource BooleanToVisibilityConverter}}" />
                                </StackPanel>''',
        '기준정보 미입력 표시')
    return once(s,
        '<Style TargetType="ComboBox">',
        '<Style TargetType="ComboBox" BasedOn="{StaticResource {x:Type ComboBox}}">',
        '신규 Master 콤보박스 공통 스타일 상속')


def dialog(s: str)->str:
    s=once(s,
        '''    bool? ShowNewMasterDialog(NewMasterViewModel viewModel);''',
        '''    bool? ShowNewMasterDialog(NewMasterViewModel viewModel);
    bool ConfirmMasterChanges(string masterKey, IReadOnlyList<DM_RMS.Wpf.Models.MasterChangePreviewItem> changes);''',
        '마스터 미리보기 IDialogService')
    s=once(s,
        '''    public bool? ShowNewMasterDialog(NewMasterViewModel viewModel)''',
        '''    public bool ConfirmMasterChanges(string masterKey, IReadOnlyList<DM_RMS.Wpf.Models.MasterChangePreviewItem> changes)
    {
        var viewModel = new MasterChangePreviewViewModel(masterKey, changes);
        var window = new MasterChangePreviewWindow { DataContext = viewModel };
        viewModel.CloseRequested += confirmed => window.DialogResult = confirmed;
        return window.ShowDialog() == true;
    }

    public bool? ShowNewMasterDialog(NewMasterViewModel viewModel)''',
        '마스터 미리보기 다이얼로그')
    return s


def recipe_archive_models(s: str)->str:
    s=once(s,
        '''    [JsonPropertyName("deleted_items")]
    public List<RecipeSelectionItem> DeletedItems { get; init; } = new();''',
        '''    [JsonPropertyName("deleted_items")]
    public List<RecipeSelectionItem> DeletedItems { get; init; } = new();

    [JsonPropertyName("results")]
    public List<RecipeOperationItemResult> Results { get; init; } = new();

    [JsonPropertyName("backup_results")]
    public List<RecipeOperationItemResult> BackupResults { get; init; } = new();

    [JsonPropertyName("delete_results")]
    public List<RecipeOperationItemResult> DeleteResults { get; init; } = new();''',
        'Recipe 결과 배열 역직렬화')
    return s + '''
/// <summary>서버 result.json에 기록된 개별 장비/Recipe 수행 내역.</summary>
public sealed class RecipeOperationItemResult
{
    [JsonPropertyName("recipe_key")]
    public string RecipeKey { get; init; } = string.Empty;
    [JsonPropertyName("success")]
    public bool Success { get; init; }
    [JsonPropertyName("source")]
    public string Source { get; init; } = string.Empty;
    [JsonPropertyName("message")]
    public string Message { get; init; } = string.Empty;
}
'''


def recipe_selection_model(s: str)->str:
    s=once(s, 'using System.Text.Json.Serialization;', 'using System.ComponentModel;\nusing System.Runtime.CompilerServices;\nusing System.Text.Json.Serialization;', '선택 레시피 알림')
    s=once(s, 'public sealed class RecipeSelectionItem\n{', '''public sealed class RecipeSelectionItem : INotifyPropertyChanged
{
    private string _operationStatus = "미처리";
    private string _operationMessage = string.Empty;

    [JsonIgnore]
    public string OperationStatus
    {
        get => _operationStatus;
        set => SetProperty(ref _operationStatus, value);
    }

    [JsonIgnore]
    public string OperationMessage
    {
        get => _operationMessage;
        set => SetProperty(ref _operationMessage, value);
    }

    public event PropertyChangedEventHandler? PropertyChanged;
    private void SetProperty<T>(ref T field, T value, [CallerMemberName] string? name = null)
    {
        if (EqualityComparer<T>.Default.Equals(field, value)) return;
        field = value;
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
    }
''', '선택 Recipe 처리상태')
    return s


def recipe_vm(s: str)->str:
    s=once(s, '    private bool _isProcessingPanelOpen;', '''    private bool _isProcessingPanelOpen;
    private bool _isRecipeOperationRunning;
    private double _equipmentPanelWidth = 560;
    private double _processingPanelWidth = 590;
    private int _lastSuccessCount;
    private int _lastFailureCount;
    private int _lastUnprocessedCount;
    private string _lastOperationSummary = "최근 실행 결과 없음";''', '슬라이드/처리상태 필드')
    s=once(s, '''            _ => HasBackupPath);''', '''            _ => HasBackupPath && !IsRecipeOperationRunning);''', '백업 중복 실행 방지')
    s=once(s, '''            _ => CanDeleteRecipes && HasBackupPath);''', '''            _ => CanDeleteRecipes && HasBackupPath && !IsRecipeOperationRunning);''', '삭제 중복 실행 방지')
    s=once(s, '''    public bool IsAnySidePanelOpen => IsEquipmentPanelOpen || IsProcessingPanelOpen;''',
        '''    public bool IsAnySidePanelOpen => IsEquipmentPanelOpen || IsProcessingPanelOpen;

    public double EquipmentPanelWidth
    {
        get => _equipmentPanelWidth;
        set => SetProperty(ref _equipmentPanelWidth, Math.Clamp(value, 440, 850));
    }
    public double ProcessingPanelWidth
    {
        get => _processingPanelWidth;
        set => SetProperty(ref _processingPanelWidth, Math.Clamp(value, 470, 900));
    }
    public bool IsRecipeOperationRunning
    {
        get => _isRecipeOperationRunning;
        private set
        {
            if (!SetProperty(ref _isRecipeOperationRunning, value)) return;
            BackupSelectedRecipesCommand.RaiseCanExecuteChanged();
            DeleteSelectedRecipesCommand.RaiseCanExecuteChanged();
        }
    }
    public int LastSuccessCount { get => _lastSuccessCount; private set => SetProperty(ref _lastSuccessCount, value); }
    public int LastFailureCount { get => _lastFailureCount; private set => SetProperty(ref _lastFailureCount, value); }
    public int LastUnprocessedCount { get => _lastUnprocessedCount; private set => SetProperty(ref _lastUnprocessedCount, value); }
    public string LastOperationSummary { get => _lastOperationSummary; private set => SetProperty(ref _lastOperationSummary, value); }

    /// <summary>
    /// ZIP result.json에서 확인한 결과만 성공으로 간주합니다.
    /// 서버 오류나 타임아웃은 성공/실패를 단정하지 않고 '확인 필요'로 표시합니다.
    /// </summary>
    private void ApplyOperationResults(string action, IReadOnlyList<RecipeOperationItemResult> results, int requestedCount)
    {
        var unique = results
            .Where(x => !string.IsNullOrWhiteSpace(x.RecipeKey))
            .GroupBy(x => x.RecipeKey, StringComparer.OrdinalIgnoreCase)
            .ToDictionary(g => g.Key, g => g.Last(), StringComparer.OrdinalIgnoreCase);
        LastSuccessCount = unique.Values.Count(x => x.Success);
        LastFailureCount = unique.Values.Count(x => !x.Success);
        LastUnprocessedCount = Math.Max(0, requestedCount - unique.Count);
        LastOperationSummary = $"최근 {action}: 성공 {LastSuccessCount:N0} / 실패 {LastFailureCount:N0} / 미처리·확인 필요 {LastUnprocessedCount:N0}";
        foreach (var item in SelectedRecipes)
        {
            var key = $"{item.EqpId}-{item.RecipeName}";
            if (unique.TryGetValue(key, out var result))
            {
                item.OperationStatus = result.Success ? "성공" : "실패";
                item.OperationMessage = result.Message;
            }
            else
            {
                item.OperationStatus = "확인 필요";
                item.OperationMessage = "서버 처리 결과가 없어 상태를 확인해야 합니다.";
            }
        }
    }

    private void MarkOperationUnknown(string action, int count)
    {
        LastSuccessCount = 0;
        LastFailureCount = 0;
        LastUnprocessedCount = count;
        LastOperationSummary = $"{action} 결과 확인 필요: {count:N0}건 (실제 처리 여부 미확인)";
        foreach (var item in SelectedRecipes)
        {
            item.OperationStatus = "확인 필요";
            item.OperationMessage = "통신·서버 오류: 실제 처리 여부를 새로고침하여 확인하세요.";
        }
    }''', 'Recipe 처리요약 및 가변 패널')
    s=once(s,
        '''            if (!_dialog.Confirm($"{SelectedRecipes.Count}개 Recipe를 백업하시겠습니까?")) return;

            var request''',
        '''            if (!_dialog.Confirm($"{SelectedRecipes.Count}개 Recipe를 백업하시겠습니까?")) return;
            IsRecipeOperationRunning = true;
            var request''', '백업 수행 중 상태')
    s=once(s,
        '''            var manifest = extracted.Manifest;
            StatusMessage = $"Recipe 백업 완료: {manifest.SuccessCount}개, 실패 {manifest.EffectiveFailureCount}개";''',
        '''            var manifest = extracted.Manifest;
            ApplyOperationResults("백업", manifest.Results, request.Items.Count);
            StatusMessage = LastOperationSummary;''', '백업 개별 결과 UI 반영')
    s=once(s,
        '''        catch (Exception ex)
        {
            StatusMessage = "Recipe 백업 실패";
            _dialog.ShowError(ex.Message);
        }
    }

    private async Task DeleteSelectedRecipesAsync()''',
        '''        catch (Exception ex)
        {
            if (IsRecipeOperationRunning) MarkOperationUnknown("백업", SelectedRecipes.Count);
            StatusMessage = "Recipe 백업 실패 · 결과 확인 필요";
            _dialog.ShowError(ex.Message);
        }
        finally
        {
            IsRecipeOperationRunning = false;
        }
    }

    private async Task DeleteSelectedRecipesAsync()''', '백업 실패/통신 오류 처리')
    s=once(s,
        '''            if (!_dialog.Confirm($"{SelectedRecipes.Count}개 Recipe를 삭제하시겠습니까?\\n장비에서 직접 삭제되는 작업입니다.")) return;

            var request''',
        '''            if (!_dialog.Confirm($"{SelectedRecipes.Count}개 Recipe를 삭제하시겠습니까?\\n장비에서 직접 삭제되는 작업입니다.")) return;
            IsRecipeOperationRunning = true;
            var request''', '삭제 수행 중 상태')
    s=once(s,
        '''            RemoveDeletedRows(manifest.DeletedItems);
            SyncSelectedRecipesFromRecipeList();
            StatusMessage = $"Recipe 삭제 완료: {manifest.DeletedCount}개, 실패 {manifest.EffectiveFailureCount}개";''',
        '''            // 성공으로 확인된 항목만 현재 화면에서 삭제합니다. 실패 항목은 선택 상태를 보존합니다.
            RemoveDeletedRows(manifest.DeletedItems);
            SyncSelectedRecipesFromRecipeList();
            ApplyOperationResults("삭제", manifest.DeleteResults, request.Items.Count);
            StatusMessage = LastOperationSummary;''', '부분 삭제 및 실패 행 표시')
    s=once(s,
        '''        catch (Exception ex)
        {
            StatusMessage = "Recipe 삭제 실패";
            _dialog.ShowError(ex.Message);
        }
    }

    private List<string> GetSelectedEquipmentIds()''',
        '''        catch (Exception ex)
        {
            if (IsRecipeOperationRunning) MarkOperationUnknown("삭제", SelectedRecipes.Count);
            StatusMessage = "Recipe 삭제 실패 · 결과 확인 필요 (장비 및 DB 재조회 권장)";
            _dialog.ShowError(ex.Message);
        }
        finally
        {
            IsRecipeOperationRunning = false;
        }
    }

    private List<string> GetSelectedEquipmentIds()''', '삭제 실패/통신 오류 처리')
    return s


def recipe_xaml(s: str)->str:
    s=once(s,
        '''<Border Width="560" HorizontalAlignment="Left" Margin="0,4,0,4"''',
        '''<Border Width="{Binding EquipmentPanelWidth}" HorizontalAlignment="Left" Margin="0,4,0,4"''',
        '장비 패널 가변 폭')
    s=once(s, '''<TranslateTransform X="-570" />''', '''<TranslateTransform X="-980" />''', '장비 패널 숨김 좌표')
    s=s.replace('To="-570" Duration="0:0:0.18"','To="-980" Duration="0:0:0.18"')
    s=once(s,
        '''<Border Width="590" HorizontalAlignment="Right" Margin="0,4,0,4"''',
        '''<Border Width="{Binding ProcessingPanelWidth}" HorizontalAlignment="Right" Margin="0,4,0,4"''',
        '처리 패널 가변 폭')
    s=once(s, '''<TranslateTransform X="600" />''', '''<TranslateTransform X="980" />''', '처리 패널 숨김 좌표')
    s=s.replace('To="600" Duration="0:0:0.18"','To="980" Duration="0:0:0.18"')
    s=once(s,
        '''                            <Button Content="닫기" Command="{Binding CloseEquipmentPanelCommand}" Margin="6,0,0,0" />''',
        '''                            <TextBlock Text="폭" VerticalAlignment="Center" Margin="4,0,2,0" />
                            <Slider Width="92" Minimum="440" Maximum="850" TickFrequency="10"
                                    Value="{Binding EquipmentPanelWidth, Mode=TwoWay, UpdateSourceTrigger=PropertyChanged}"
                                    ToolTip="장비 현황 패널 폭 조절" VerticalAlignment="Center" />
                            <Button Content="닫기" Command="{Binding CloseEquipmentPanelCommand}" Margin="6,0,0,0" />''',
        '장비 패널 폭 슬라이더')
    s=once(s,
        '''                            <Button Content="닫기" Command="{Binding CloseProcessingPanelCommand}" Margin="6,0,0,0" />''',
        '''                            <TextBlock Text="폭" VerticalAlignment="Center" Margin="4,0,2,0" />
                            <Slider Width="92" Minimum="470" Maximum="900" TickFrequency="10"
                                    Value="{Binding ProcessingPanelWidth, Mode=TwoWay, UpdateSourceTrigger=PropertyChanged}"
                                    ToolTip="처리 Recipe 패널 폭 조절" VerticalAlignment="Center" />
                            <Button Content="닫기" Command="{Binding CloseProcessingPanelCommand}" Margin="6,0,0,0" />''',
        '처리 패널 폭 슬라이더')
    s=once(s,
        '''                            <DataGridTextColumn Header="Recipe" Binding="{Binding RecipeName}" Width="1.55*" />''',
        '''                            <DataGridTextColumn Header="Recipe" Binding="{Binding RecipeName}" Width="1.55*" />
                            <DataGridTextColumn Header="결과" Binding="{Binding OperationStatus}" Width="65" />
                            <DataGridTextColumn Header="상세" Binding="{Binding OperationMessage}" Width="1.25*" />''',
        'Recipe 개별 결과 컬럼')
    s=once(s,
        '''                    <Border Grid.Row="2" Style="{StaticResource ProcessingActionPanelStyle}" Margin="0,10,0,0">
                        <StackPanel>''',
        '''                    <Border Grid.Row="2" Style="{StaticResource ProcessingActionPanelStyle}" Margin="0,10,0,0">
                        <StackPanel>
                            <TextBlock Text="{Binding LastOperationSummary}" FontWeight="SemiBold" TextWrapping="Wrap" Margin="2,0,0,5" />
                            <StackPanel Orientation="Horizontal" Margin="0,0,0,7">
                                <TextBlock Text="성공 " /><TextBlock Text="{Binding LastSuccessCount}" Foreground="#166534" FontWeight="Bold" />
                                <TextBlock Text="    실패 " /><TextBlock Text="{Binding LastFailureCount}" Foreground="#B91C1C" FontWeight="Bold" />
                                <TextBlock Text="    미처리·확인 필요 " /><TextBlock Text="{Binding LastUnprocessedCount}" Foreground="#92400E" FontWeight="Bold" />
                            </StackPanel>''',
        'Recipe 처리요약 UI')
    return s


def login_vm(s: str)->str:
    s=once(s, '''    private readonly ApiHostProvider _apiHostProvider;''',
        '''    private readonly ApiHostProvider _apiHostProvider;
    private readonly IDialogService _dialogs = new DialogService();''', '로그인 공통 다이얼로그')
    s=once(s,
        '''        try
        {
            IsBusy = true;
            StatusMessage = "로그인 요청 중...";

            string baseUrl''',
        '''        await UiOperationRunner.RunAsync(async () =>
        {
            string baseUrl''', '로그인 공통 비동기 래퍼 시작')
    s=once(s,
        '''            LoginSucceeded?.Invoke(this, session);
        }
        catch (Exception ex)
        {
            StatusMessage = "로그인 실패";
            System.Windows.MessageBox.Show(
                ex.Message,
                "로그인 실패",
                System.Windows.MessageBoxButton.OK,
                System.Windows.MessageBoxImage.Error);
        }
        finally
        {
            IsBusy = false;
        }''',
        '''            LoginSucceeded?.Invoke(this, session);
        }, _dialogs, value => IsBusy = value, value => StatusMessage = value,
           "로그인 요청 중...", "로그인 실패");''', '로그인 공통 비동기 래퍼 종료')
    return s


def register_vm(s: str)->str:
    s=once(s, '''    private readonly ApiHostProvider _apiHostProvider;''',
        '''    private readonly ApiHostProvider _apiHostProvider;
    private readonly IDialogService _dialogs = new DialogService();''', '등록 공통 다이얼로그')
    s=once(s,
        '''        try
        {
            IsBusy = true;
            StatusMessage = "신규 등록 요청 중...";

            string baseUrl''',
        '''        await UiOperationRunner.RunAsync(async () =>
        {
            string baseUrl''', '등록 공통 비동기 래퍼 시작')
    s=once(s,
        '''            RegisterSucceeded?.Invoke(this, EventArgs.Empty);
        }
        catch (Exception ex)
        {
            StatusMessage = "신규 등록 실패";
            System.Windows.MessageBox.Show(
                ex.Message,
                "신규 등록 실패",
                System.Windows.MessageBoxButton.OK,
                System.Windows.MessageBoxImage.Error);
        }
        finally
        {
            IsBusy = false;
        }''',
        '''            RegisterSucceeded?.Invoke(this, EventArgs.Empty);
        }, _dialogs, value => IsBusy = value, value => StatusMessage = value,
           "신규 등록 요청 중...", "신규 등록 실패");''', '등록 공통 비동기 래퍼 종료')
    return s


FRONT_PATCHES = {
    'Resources/Theme.xaml': theme,
    'Views/MasterManagementView.xaml': master_view,
    'ViewModels/MasterManagementViewModel.cs': master_vm,
    'Models/MasterModels.cs': master_filter_model,
    'ViewModels/NewMasterViewModel.cs': new_master_vm,
    'Views/NewMasterWindow.xaml': new_master_view,
    'Services/DialogService.cs': dialog,
    'Models/RecipeArchiveModels.cs': recipe_archive_models,
    'Models/RecipeSelectionItem.cs': recipe_selection_model,
    'ViewModels/RecipeManagementViewModel.cs': recipe_vm,
    'Views/RecipeManagementView.xaml': recipe_xaml,
    'ViewModels/LoginViewModel.cs': login_vm,
    'ViewModels/RegisterViewModel.cs': register_vm,
}


def main()->int:
    p=argparse.ArgumentParser(description='DM RMS 리뉴얼 3차 UI/UX 패치')
    p.add_argument('--root', required=True, type=Path, help='GitHub 프로젝트 루트 폴더')
    p.add_argument('--dry-run', action='store_true', help='수정 없이 검증만 진행')
    args=p.parse_args()
    root=args.root.resolve()
    if not (root/FRONT/'DM_RMS.Wpf.csproj').is_file():
        p.error('DMRMS_Renewal 프로젝트 루트를 지정해 주세요.')
    changes:dict[Path,str]={}
    for relative,fn in FRONT_PATCHES.items():
        file=FRONT/relative
        changes[file]=fn((root/file).read_text(encoding='utf-8-sig'))
    package=Path(__file__).parent
    for f in (package/'extra').rglob('*'):
        if f.is_file():
            dest=FRONT/f.relative_to(package/'extra')
            if (root/dest).exists():
                raise ValueError(f'새로 생성할 파일이 이미 있습니다: {dest}')
            changes[dest]=f.read_text(encoding='utf-8')
    doc=Path('docs/3차_UIUX_변경사항.md')
    if (root/doc).exists():
        raise ValueError(f'수정 내역 문서가 이미 있습니다: {doc}')
    changes[doc]=(package/'docs/3차_UIUX_변경사항.md').read_text(encoding='utf-8')
    print(f'[사전 점검 통과] 변경/추가 대상 {len(changes)}개 파일')
    for f in changes: print(' -',f)
    if args.dry_run:
        print('dry-run: 실제 파일은 수정되지 않았습니다.')
        return 0
    backup=root/f'.dmrms_patch_backup_v3_{datetime.now():%Y%m%d_%H%M%S}'
    for rel in changes:
        if (root/rel).is_file():
            dst=backup/rel
            dst.parent.mkdir(parents=True,exist_ok=True)
            shutil.copy2(root/rel,dst)
    modified=[]
    try:
        for rel,data in changes.items():
            out=root/rel
            out.parent.mkdir(parents=True,exist_ok=True)
            tmp=out.with_suffix(out.suffix+'.dmrms_v3_tmp')
            tmp.write_text(data,encoding='utf-8')
            tmp.replace(out)
            modified.append(rel)
    except Exception:
        for rel in reversed(modified):
            prev=backup/rel
            if prev.is_file():shutil.copy2(prev,root/rel)
            else:(root/rel).unlink(missing_ok=True)
        raise
    print('[완료] 원본 백업:',backup)
    print('[안내] Windows dotnet build, FAB1/FAB2 운영 API 검증을 완료한 뒤 배포하세요.')
    return 0

if __name__=='__main__':
    try:raise SystemExit(main())
    except (OSError,ValueError) as e:
        print('[패치 오류]',e,file=sys.stderr)
        raise SystemExit(1) from e
