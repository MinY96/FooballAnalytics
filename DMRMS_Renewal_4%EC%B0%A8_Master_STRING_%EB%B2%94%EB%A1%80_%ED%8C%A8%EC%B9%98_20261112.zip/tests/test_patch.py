"""4차 패치의 최소 동작 및 SQL 접근 패턴 검증(외부 DB 불필요)."""
from __future__ import annotations
import ast
from pathlib import Path
import tempfile
import unittest
import xml.etree.ElementTree as ET

BASE = Path(__file__).resolve().parents[1]


class FakeFrame:
    def __init__(self, rows):
        self.rows = rows

    def to_dict(self, orient):
        assert orient == "records"
        return [row.copy() for row in self.rows]


class FakeCrud:
    queries = []
    rows = []
    values = []

    @classmethod
    def select_query(cls, query, parameters):
        cls.queries.append((query, parameters))
        if "JOIN dm_master_recipe_info dmri" in query:
            return FakeFrame(cls.rows)
        if "JOIN dm_recipe_para drp" in query:
            if parameters[0] != "KLA2139":
                raise AssertionError("잘못된 Model을 전달했습니다")
            return FakeFrame(cls.values)
        raise AssertionError("알 수 없는 SQL")


def clone_parameter(row):
    return {
        "parameter_name": row.get("parameter_name", ""),
        "display_value": row.get("display_value", ""),
        "control_type": row.get("control_type", "STRING"),
        "allowed_values": list(row.get("allowed_values") or []),
    }


def load_function():
    source = (BASE / "overrides/master_detail.pyfrag").read_text(encoding="utf-8")
    tree = ast.parse(source)
    assert len(tree.body) == 1 and isinstance(tree.body[0], ast.FunctionDef)
    namespace = {"PostgresCRUD": FakeCrud, "_clone_parameter": clone_parameter}
    exec(compile(tree, "master_detail.pyfrag", "exec"), namespace)
    return namespace["master_detail"]


class TestMasterDetail(unittest.TestCase):
    def setUp(self):
        FakeCrud.queries.clear()
        FakeCrud.rows = [
            {"parameter_name": "edge", "display_value": "F0/F1", "control_type": "STRING", "master_model": "KLA2139"},
            {"parameter_name": "pattern", "display_value": "A", "control_type": "STRING", "master_model": "KLA2139"},
            {"parameter_name": "threshold", "display_value": "2.1", "control_type": "DOUBLE", "master_model": "KLA2139"},
        ]
        FakeCrud.values = [
            {"parameter_name": "edge", "para_value": "F0"},
            {"parameter_name": "edge", "para_value": "F1"},
            {"parameter_name": "pattern", "para_value": "A"},
        ]

    def test_model_and_batch_query(self):
        r = load_function()("KLA2139_00001")
        self.assertEqual(r["master_key"], "KLA2139_00001")
        self.assertEqual(len(FakeCrud.queries), 2)
        self.assertEqual(FakeCrud.queries[0][1], ("KLA2139_00001",))
        self.assertEqual(FakeCrud.queries[1][1], ("KLA2139", ["edge", "pattern"]))
        self.assertIn("dri.model = %s", FakeCrud.queries[1][0])
        self.assertIn("dri.is_remove = false", FakeCrud.queries[1][0])
        self.assertIn("drp.para_nm = ANY(%s)", FakeCrud.queries[1][0])
        self.assertEqual(r["parameters"][0]["allowed_values"], ["F0", "F1"])
        self.assertEqual(r["parameters"][1]["allowed_values"], ["A"])
        self.assertEqual(r["parameters"][2]["allowed_values"], [])
        self.assertEqual(r["parameters"][0]["display_value"], "F0/F1")

    def test_no_string_parameters_only_one_query(self):
        FakeCrud.rows = [{"parameter_name": "num", "display_value": "2", "control_type": "INTEGER", "master_model": "KLA2139"}]
        r = load_function()("KLA2139_00001")
        self.assertEqual(len(FakeCrud.queries), 1)
        self.assertEqual(r["parameters"][0]["allowed_values"], [])

    def test_no_rows_no_extra_query(self):
        FakeCrud.rows = []
        r = load_function()("NOT_FOUND")
        self.assertEqual(r["parameters"], [])
        self.assertEqual(len(FakeCrud.queries), 1)


class TestPatch(unittest.TestCase):
    def test_xaml_replacements(self):
        import sys
        sys.path.insert(0, str(BASE))
        import apply_patch
        xaml_master = '''<UserControl xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"><DataTemplate x:Key="StringEditTemplate" xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml">
            <ComboBox ItemsSource="{Binding AllowedValues}"
                      SelectedItem="{Binding EditValue, UpdateSourceTrigger=PropertyChanged}"
                      IsEnabled="{Binding IsEditMode}"
                      MinWidth="140" />
                            <TextBlock Text="Parameter별 Master 설정값을 확인하고, 편집 모드에서 변경된 행만 저장합니다."
                                       Style="{StaticResource MutedTextStyle}" />
        </DataTemplate></UserControl>'''
        fixed = apply_patch.update_master_xaml(xaml_master, "MasterManagementView.xaml")
        ET.fromstring(fixed)
        self.assertIn('IsEditable="True"', fixed)
        self.assertIn('Text="{Binding EditValue, Mode=TwoWay, UpdateSourceTrigger=PropertyChanged}"', fixed)
        self.assertIn("F0/F1/F2", fixed)
        xaml_recipe = '''<UserControl xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation">
                                <TextBlock Text="체크 시 우측 처리 목록에 반영되며, 행 더블클릭 시 하단에서 상세 Parameter를 조회합니다."
                                           Style="{StaticResource MutedTextStyle}" /></UserControl>'''
        changed = apply_patch.update_recipe_xaml(xaml_recipe, "RecipeManagementView.xaml")
        ET.fromstring(changed)
        self.assertIn('Background="#E2EFDA"', changed)
        self.assertIn("Master 생성이 필요한 Recipe", changed)

    def test_server_splice(self):
        import sys
        sys.path.insert(0, str(BASE))
        import apply_patch
        sample = '''def master_detail(master_key: str) -> dict:\n    rows = PostgresCRUD.select_query(''' + "\"\"\"SELECT DISTINCT para_value FROM dm_master_recipe_para\n\"\"\"" + ''')\n    return rows\n\ndef parameter_options(model: str) -> list[dict]:\n    return []\n'''
        fixed = apply_patch.update_server(sample, "mock master_data.py")
        ast.parse(fixed)
        self.assertEqual(fixed.count("def master_detail"), 1)
        self.assertIn("JOIN dm_recipe_para drp", fixed)
        self.assertNotIn("SELECT DISTINCT para_value FROM dm_master_recipe_para", fixed)


if __name__ == "__main__":
    unittest.main()
