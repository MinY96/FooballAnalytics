# DM RMS Renewal — 4차 수정 패치

> 기준 소스: GitHub `MinY96/DMRMS_Renewal`, `master` 커밋 `d86fa6cf80930a41397655e2d89fd15fac9a73d4` (2026-11-12 조회).  
> 대상: FAB1 / FAB2 API + WPF 프론트엔드. **DB 구조 변경 없음.**

## 1. 반영 사항

### 1-1. Master Recipe 관리 — STRING 설정값 선택지 개선

**이전**: `master_detail(master_key)`는 `dm_master_recipe_para`의 `para_nm`만으로 고유값을 검색했습니다. 현재 선택한 Master의 Model과 관련 없는 값이 나타날 수 있고, 실제 파싱 Recipe에만 존재하는 값은 검색되지 않을 수 있습니다.

**변경**: `master_key`로 `dm_master_recipe_info.model`을 확인하고 해당 Model의 `dm_recipe_info` ↔ `dm_recipe_para`에서 문자열 Parameter의 실제 고유값을 조회합니다.

```sql
SELECT DISTINCT
    drp.para_nm AS parameter_name,
    drp.para_value AS para_value
FROM dm_recipe_info dri
JOIN dm_recipe_para drp
    ON dri.recipe_key = drp.recipe_key
WHERE dri.model = %s
  AND dri.is_remove = false
  AND drp.para_nm = ANY(%s)
  AND drp.para_value IS NOT NULL
  AND BTRIM(drp.para_value) <> ''
ORDER BY drp.para_nm, drp.para_value;
```

- `%s`의 Model 값은 **해당 Master Key가 DB에서 소속된 Model**입니다. 클라이언트 입력으로 Model을 신뢰하지 않습니다.
- `ANY(%s)`에 해당 Master의 **STRING Parameter 목록**을 전달하므로 Parameter가 수십~수백 개인 경우에도 기존의 Parameter별 N+1 조회를 피할 수 있습니다.
- 조회 목록에서 다른 Model의 파싱값을 제외합니다.
- **현재 저장된 Master 설정값**은 파싱 고유값 목록에 없더라도 WPF `MasterParameterItem.FromDto()`에서 표시가 유지됩니다.
- 관리용 설정값을 목록 밖에서 직접 입력할 수 있으며, `/`로 다중값을 지정할 수 있습니다. 예: `F0/F1/F2`.

**유의:** 현재 `1_backup/fab1`, `fab2`의 `check_para_matching`은 `/` 구분 값을 `master.split("/")`로 비교하므로, `F0 / F1`처럼 **공백을 넣지 말고** `F0/F1`로 입력하세요. (집계 워커 비교 로직은 이번 패치에서 변경하지 않았습니다.)

### 1-2. WPF 상세 Parameter 수정 콤보박스

- `IsEditable="True"`로 **목록 선택 및 직접 타이핑**을 모두 허용합니다.
- `SelectedItem` 바인딩 대신 `Text` 양방향 바인딩을 사용해, 목록에 없는 값이나 `F0/F1/F2`도 `EditValue`에 반영됩니다.
- Master 상세 Parameter 제목 아래에 `STRING 타입은 ... /로 구분 ...` 안내 문구를 추가합니다.
- 이미 구현된 편집 권한, 변경 건수, 저장 전 미리보기 기능은 그대로 유지합니다.

### 1-3. Recipe 관리 — 초록색 행 범례

- Recipe 리스트 제목 아래에 기존 하이라이트 색상 `#E2EFDA`의 작은 사각형과 안내 문구를 추가합니다.
- 문구: **초록색 하이라이트: Master 생성이 필요한 Recipe입니다.**
- `RecipeRowHighlightBehavior`의 기존 조건(`matching`이 비어 있고 `no_master=True`) 및 분홍색 불일치 표시의 우선순위를 변경하지 않습니다.

## 2. 수정 파일

| 경로 | 내용 |
| --- | --- |
| `2_server/fab1/src/data/master_data.py` | Model별 파싱값 배치 조회 |
| `2_server/fab2/src/data/master_data.py` | FAB2 동일 처리 |
| `3_frontend/DM_RMS.Wpf/Views/MasterManagementView.xaml` | 편집 가능한 STRING 콤보박스·안내 문구 |
| `3_frontend/DM_RMS.Wpf/Views/RecipeManagementView.xaml` | 초록색 하이라이트 범례 |

## 3. 적용 방법 (Windows)

1. 최신 프로젝트를 **GitHub에서 Pull**하고, 현재 작업 내용을 커밋하거나 안전한 복사본을 보관합니다.
2. 이 ZIP 파일을 **별도 폴더**에 압축 해제합니다.
3. 압축 해제한 폴더에서 PowerShell 또는 CMD 명령어를 실행합니다.

```bat
REM 적용 가능 여부 확인 (파일 수정 없음)
py -3.12 apply_patch.py --root "D:\DMRMS_Renewal" --dry-run

REM 실제 적용
py -3.12 apply_patch.py --root "D:\DMRMS_Renewal"

REM 변경사항 비교
cd /d D:\DMRMS_Renewal
git diff -- 2_server/fab1/src/data/master_data.py 2_server/fab2/src/data/master_data.py 3_frontend/DM_RMS.Wpf/Views/MasterManagementView.xaml 3_frontend/DM_RMS.Wpf/Views/RecipeManagementView.xaml
```

패치는 **기존 함수와 XAML 구문의 일치 여부를 먼저 검사**합니다. 버전이 다르면 파일을 수정하지 않고 중단합니다. 성공적으로 적용할 때는 저장소 안에 `.dmrms_v4_backup_날짜시간` 폴더를 만들고 대상 4개 파일을 백업합니다. 해당 백업 폴더는 필요에 따라 Git에 포함되지 않도록 주의하세요.

## 4. 로컬 테스트 및 빌드

```bat
REM 패치 자체 단위 테스트(표준 라이브러리만 사용)
py -3.12 -m unittest discover -s tests -v

REM FAB1/FAB2 서버에서 기존 환경을 활성화한 후
cd /d D:\DMRMS_Renewal\2_server\fab1
.venv\Scripts\activate
python -m pytest -q
python run.py

REM FAB2도 동일하게 별도 터미널에서 확인
cd /d D:\DMRMS_Renewal\2_server\fab2
.venv\Scripts\activate
python -m pytest -q
python run.py

REM WPF (실제 솔루션/프로젝트 위치에 맞게 실행)
cd /d D:\DMRMS_Renewal\3_frontend
dotnet build -c Release
```

서버 `run.py`는 개발 실행용이며, 운영 실행은 기존 Waitress 설정을 유지하세요. 포트/호스트 및 DB 접속 설정(`.env`)은 기존 운영 값을 유지합니다.

## 5. 기능 확인 절차

1. **FAB1/KLA2139**, **FAB2의 STRING Parameter가 포함된 Model**을 각각 선택해 Master 상세를 조회합니다.
2. `edge` 등 실제 파싱값들이 콤보박스에 나타나는지 확인합니다.
3. 다른 Model의 값이 섞이지 않는지 확인합니다.
4. 콤보박스에서 항목을 선택해 기존값→변경값 미리보기로 넘어가는지 확인합니다.
5. `F0/F1/F2` 같은 **목록에 없는 값**을 직접 입력하고, 변경 미리보기→저장→재조회 시 동일한 값이 남는지 확인합니다.
6. 숫자 및 범위 타입 Parameter의 기존 편집 기능이 그대로 작동하는지 확인합니다.
7. Recipe 관리 탭에서 초록색 행과 범례 색상이 동일하게 나타나는지 확인합니다.

## 6. 검증 범위와 제한

- 사용자 GitHub 소스의 해당 함수와 XAML 구문을 직접 확인하여 변경 기준을 선정했습니다.
- SQL 실행 건수를 모사하는 Python 단위 테스트를 포함했습니다.
- **실제 PostgreSQL 서버/FAB 장비 연결 및 Windows WPF 실사용 환경에서 테스트한 것은 아닙니다.** 적용 후 위의 기능 확인 절차를 수행하세요.
- 이번 변경은 조회·표시 로직이며 **DB 스키마 변경 및 Master Matching 집계 로직 변경은 없습니다.**
