#!/usr/bin/env python3
"""DM RMS 리뉴얼 4차: FAB1/2 master_detail 및 WPF 범례·콤보박스 안전 패치."""
from __future__ import annotations
import argparse
from datetime import datetime
from pathlib import Path
import re
import shutil
import sys


SCRIPT_DIR = Path(__file__).resolve().parent
FRAG = (SCRIPT_DIR / "overrides" / "master_detail.pyfrag").read_text(encoding="utf-8")
SERVER_PATHS = [
    "2_server/fab1/src/data/master_data.py",
    "2_server/fab2/src/data/master_data.py",
]
MASTER_XAML = "3_frontend/DM_RMS.Wpf/Views/MasterManagementView.xaml"
RECIPE_XAML = "3_frontend/DM_RMS.Wpf/Views/RecipeManagementView.xaml"


def replace_once(content: str, old: str, new: str, path: str) -> str:
    n = content.count(old)
    if n != 1:
        raise RuntimeError(f"[{path}] 기준 코드 확인 실패(일치 횟수={n}). 최신 GitHub 파일인지 확인하세요.")
    return content.replace(old, new, 1)


def update_server(text: str, path: str) -> str:
    pattern = r"(?m)^def master_detail\(master_key: str\) -> dict:\n.*?(?=^def parameter_options\(model: str\) -> list\[dict\]:)"
    matched = re.search(pattern, text, flags=re.DOTALL | re.MULTILINE)
    if not matched:
        raise RuntimeError(f"[{path}] master_detail 정의를 찾을 수 없습니다.")
    before = matched.group(0)
    if "FROM dm_master_recipe_para \n" not in before and "FROM dm_master_recipe_para\n" not in before:
        raise RuntimeError(f"[{path}] 기존 고유값 SQL 구조가 달라 패치를 중단했습니다.")
    if "SELECT DISTINCT para_value" not in before:
        raise RuntimeError(f"[{path}] 해당 함수가 이미 수정되었거나 구조가 달라 패치를 중단했습니다.")
    return text[:matched.start()] + FRAG + "\n\n" + text[matched.end():]


def update_master_xaml(text: str, path: str) -> str:
    old = '''            <ComboBox ItemsSource="{Binding AllowedValues}"
                      SelectedItem="{Binding EditValue, UpdateSourceTrigger=PropertyChanged}"
                      IsEnabled="{Binding IsEditMode}"
                      MinWidth="140" />'''
    new = '''            <ComboBox ItemsSource="{Binding AllowedValues}"
                      Text="{Binding EditValue, Mode=TwoWay, UpdateSourceTrigger=PropertyChanged}"
                      IsEditable="True"
                      IsTextSearchEnabled="False"
                      IsEnabled="{Binding IsEditMode}"
                      ToolTip="실제 파싱값 선택 또는 직접 입력 가능. 다중 값은 /로 구분하세요(예: F0/F1/F2)."
                      MinWidth="140" />'''
    text = replace_once(text, old, new, path)
    old_note = '''                            <TextBlock Text="Parameter별 Master 설정값을 확인하고, 편집 모드에서 변경된 행만 저장합니다."
                                       Style="{StaticResource MutedTextStyle}" />'''
    new_note = old_note + '''
                            <TextBlock Text="STRING 타입은 실제 파싱값을 선택하거나 직접 입력할 수 있습니다. 여러 값은 /로 구분하세요 (예: F0/F1/F2)."
                                       Foreground="#006100" FontSize="12" TextWrapping="Wrap" Margin="0,4,0,0" />'''
    text = replace_once(text, old_note, new_note, path)
    return text


def update_recipe_xaml(text: str, path: str) -> str:
    old = '''                                <TextBlock Text="체크 시 우측 처리 목록에 반영되며, 행 더블클릭 시 하단에서 상세 Parameter를 조회합니다."
                                           Style="{StaticResource MutedTextStyle}" />'''
    new = old + '''
                                <!-- RecipeRowHighlightBehavior.NoMasterBackground(#E2EFDA)와 동일한 범례 색상 -->
                                <StackPanel Orientation="Horizontal" Margin="0,5,0,0" VerticalAlignment="Center">
                                    <Border Width="14" Height="14" CornerRadius="2" BorderThickness="1"
                                            Background="#E2EFDA" BorderBrush="#AAC99A" Margin="0,0,7,0" />
                                    <TextBlock Text="초록색 하이라이트: Master 생성이 필요한 Recipe입니다."
                                               Foreground="#006100" FontSize="12" VerticalAlignment="Center" />
                                </StackPanel>'''
    return replace_once(text, old, new, path)


def main() -> int:
    parser = argparse.ArgumentParser(description="DM RMS 4차 변경사항 패치 (FAB1/FAB2/WPF)")
    parser.add_argument("--root", type=Path, required=True, help="DMRMS_Renewal 리포지토리 루트")
    parser.add_argument("--dry-run", action="store_true", help="검증만 수행하고 파일을 수정하지 않음")
    opts = parser.parse_args()
    root = opts.root.expanduser().resolve()
    if not root.is_dir():
        parser.error(f"경로가 존재하지 않습니다: {root}")

    changed = {}
    for rel in [*SERVER_PATHS, MASTER_XAML, RECIPE_XAML]:
        path = root / rel
        if not path.is_file():
            raise FileNotFoundError(f"대상 파일이 없습니다: {path}")
        original = path.read_text(encoding="utf-8-sig")
        if rel in SERVER_PATHS:
            replacement = update_server(original, rel)
        elif rel == MASTER_XAML:
            replacement = update_master_xaml(original, rel)
        else:
            replacement = update_recipe_xaml(original, rel)
        if replacement == original:
            raise RuntimeError(f"[{rel}] 변경 내용이 없습니다.")
        changed[rel] = (original, replacement)

    print(f"검증 완료: {len(changed)}개 파일 | 프로젝트: {root}")
    for rel in changed:
        print(f"  - {rel}")
    if opts.dry_run:
        print("--dry-run: 실제 파일은 변경하지 않았습니다.")
        return 0

    backup = root / f".dmrms_v4_backup_{datetime.now():%Y%m%d_%H%M%S}"
    # 모두 백업한 뒤에만 쓰기 시작한다.
    for rel in changed:
        target = backup / rel
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(root / rel, target)

    written = []
    try:
        for rel, (_, replacement) in changed.items():
            target = root / rel
            target.write_text(replacement, encoding="utf-8")
            written.append(rel)
    except Exception:
        for rel in written:
            shutil.copy2(backup / rel, root / rel)
        raise

    print(f"완료: 원본 백업 {backup}")
    print("다음: Windows에서 dotnet build 및 FAB1/FAB2 API 검증")
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except (OSError, RuntimeError, ValueError) as error:
        print(f"패치 중단: {error}", file=sys.stderr)
        sys.exit(1)
